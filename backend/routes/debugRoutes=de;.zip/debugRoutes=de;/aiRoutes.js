// ============================================================
// AI ROUTES - COMPLETE VERSION
// ============================================================

import { Router } from "express";
import {
  handleAIConversation,
  handleAIReview,
  handleAITaxQuestion,
  getWelcomeMessage,
  getStatus,
  resetSession,
  getAllData,
  updateField,
  updateMultipleFields
} from "../controllers/smartAiController.js";

const router = Router();

// Main chat endpoint
router.post("/chat", handleAIConversation);

// Welcome message
router.post("/welcome", getWelcomeMessage);

// Get current status/phase
router.get("/status", getStatus);
router.post("/status", getStatus);

// Review tax return
router.post("/review", handleAIReview);

// Ask tax question
router.post("/advisor", handleAITaxQuestion);
router.post("/question", handleAITaxQuestion);

// Get all user data from MongoDB
router.post("/data", getAllData);

// Update specific field (single)
router.post("/update-field", updateField);

// Update multiple fields (batch) - used by SubmitFlow
router.post("/update", updateMultipleFields);

// Reset session (clear all data)
router.post("/reset", resetSession);

export default router;
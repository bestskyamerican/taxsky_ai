// ============================================================
// FILE ROUTES - SMART UPLOAD WITH SPOUSE DETECTION
// ============================================================

import express from "express";
import axios from "axios";
import { getSession, saveAnswer } from "../tax/sessionDB.js";

const router = express.Router();
const PYTHON_OCR = process.env.PYTHON_OCR_URL || "http://localhost:5001";

router.post("/upload", async (req, res) => {
  console.log("\n" + "=".repeat(60));
  console.log("[UPLOAD] Document received");
  console.log("[UPLOAD] req.files keys:", req.files ? Object.keys(req.files) : "none");
  
  try {
    const { userId, isSpouse } = req.body;
    
    // Accept: 'document', 'file', 'image', or any first file
    let file = null;
    if (req.files) {
      file = req.files.document || req.files.file || req.files.image || Object.values(req.files)[0];
    }
    
    if (!file) {
      console.log("[UPLOAD] ❌ No file found!");
      return res.status(400).json({ error: "No file uploaded" });
    }
    
    const fileName = file.name.toLowerCase();
    let forceSpouse = isSpouse === 'true' || isSpouse === true;
    
    console.log(`[UPLOAD] User: ${userId}, File: ${file.name}, Spouse: ${forceSpouse}`);
    
    // Get session
    let a = new Map();
    try {
      const s = await getSession(userId);
      a = s.answers || new Map();
    } catch(e) {}
    
    // ========== SMART SPOUSE DETECTION ==========
    const filing = a.get('filing_status');
    const spouseHasW2 = a.get('spouse_has_w2');
    const spouseW2Done = a.get('spouse_w2_uploaded') === 'yes';
    const spouseWages = parseFloat(a.get('spouse_total_wages')) || 0;
    const taxpayerW2Count = parseInt(a.get('w2_count')) || 0;
    
    // Auto-detect: If MFJ + spouse said yes to W-2 + we have taxpayer W-2 + no spouse W-2 yet
    if (!forceSpouse && filing === 'married_filing_jointly' && spouseHasW2 === 'yes' && taxpayerW2Count >= 1 && !spouseW2Done && spouseWages === 0) {
      forceSpouse = true;
      console.log("[UPLOAD] 🔍 AUTO-DETECTED AS SPOUSE DOCUMENT!");
    }
    
    // Detect form type
    let formType = 'W-2';
    if (fileName.includes('1099') && fileName.includes('int')) formType = '1099-INT';
    else if (fileName.includes('1099') && fileName.includes('nec')) formType = '1099-NEC';
    else if (fileName.includes('1099') && fileName.includes('div')) formType = '1099-DIV';
    else if (fileName.includes('int')) formType = '1099-INT';
    
    console.log(`[UPLOAD] Form type: ${formType}, Is Spouse: ${forceSpouse}`);
    
    // Call OCR
    const endpoint = { 'W-2': '/ocr/w2', '1099-INT': '/ocr/int', '1099-NEC': '/ocr/nec', '1099-DIV': '/ocr/div' }[formType] || '/ocr/w2';
    console.log(`[OCR] Calling: ${PYTHON_OCR}${endpoint}`);
    
    const formData = new FormData();
    formData.append('file', new Blob([file.data]), file.name);
    
    let ocr;
    try {
      const r = await axios.post(`${PYTHON_OCR}${endpoint}`, formData, { headers: {'Content-Type':'multipart/form-data'}, timeout: 30000 });
      ocr = r.data.extracted;
      console.log("[OCR] Python response:", JSON.stringify(r.data, null, 2));
    } catch(e) {
      console.error("[OCR] Error:", e.message);
      return res.status(500).json({ error: "OCR failed" });
    }
    
    if (!ocr) return res.status(500).json({ error: "OCR returned no data" });
    
    // ========== SAVE DATA ==========
    let result = {};
    
    if (formType === 'W-2') {
      if (forceSpouse) {
        // ===== SPOUSE W-2 =====
        const cnt = (parseInt(a.get('spouse_w2_count')) || 0) + 1;
        await saveAnswer(userId, `spouse_w2_${cnt}_raw`, JSON.stringify(ocr));
        await saveAnswer(userId, `spouse_w2_${cnt}_employer`, ocr.employer_name);
        await saveAnswer(userId, `spouse_w2_${cnt}_wages`, ocr.wages_tips_other_comp);
        await saveAnswer(userId, `spouse_w2_${cnt}_withheld`, ocr.federal_income_tax_withheld);
        
        const prevW = parseFloat(a.get('spouse_total_wages')) || 0;
        const prevH = parseFloat(a.get('spouse_total_withheld')) || 0;
        await saveAnswer(userId, 'spouse_total_wages', prevW + (ocr.wages_tips_other_comp || 0));
        await saveAnswer(userId, 'spouse_total_withheld', prevH + (ocr.federal_income_tax_withheld || 0));
        await saveAnswer(userId, 'spouse_w2_count', cnt);
        await saveAnswer(userId, 'spouse_w2_uploaded', 'yes');
        
        result = { success: true, owner: 'spouse', type: 'W-2', employer: ocr.employer_name, wages: ocr.wages_tips_other_comp, withheld: ocr.federal_income_tax_withheld };
        console.log(`[UPLOAD] ✅ SPOUSE W-2 #${cnt}: $${ocr.wages_tips_other_comp}`);
        
      } else {
        // ===== TAXPAYER W-2 =====
        const cnt = (parseInt(a.get('w2_count')) || 0) + 1;
        await saveAnswer(userId, `w2_${cnt}_raw`, JSON.stringify(ocr));
        await saveAnswer(userId, `w2_${cnt}_employer`, ocr.employer_name);
        await saveAnswer(userId, `w2_${cnt}_wages`, ocr.wages_tips_other_comp);
        await saveAnswer(userId, `w2_${cnt}_withheld`, ocr.federal_income_tax_withheld);
        await saveAnswer(userId, `w2_${cnt}_state_wages`, ocr.state_wages);
        await saveAnswer(userId, `w2_${cnt}_state_withheld`, ocr.state_income_tax);
        await saveAnswer(userId, `w2_${cnt}_confirmed`, false);
        
        const prevW = parseFloat(a.get('total_wages')) || 0;
        const prevH = parseFloat(a.get('total_withheld')) || 0;
        const prevS = parseFloat(a.get('total_state_withheld')) || 0;
        await saveAnswer(userId, 'total_wages', prevW + (ocr.wages_tips_other_comp || 0));
        await saveAnswer(userId, 'total_withheld', prevH + (ocr.federal_income_tax_withheld || 0));
        await saveAnswer(userId, 'total_state_withheld', prevS + (ocr.state_income_tax || 0));
        await saveAnswer(userId, 'w2_count', cnt);
        
        // Personal info from first W-2
        if (cnt === 1) {
          const name = (ocr.employee_name || '').split(' ');
          await saveAnswer(userId, 'first_name', name[0] || '');
          await saveAnswer(userId, 'last_name', name.slice(1).join(' ') || '');
          await saveAnswer(userId, 'ssn', ocr.employee_ssn || '');
          await saveAnswer(userId, 'address', ocr.employee_address || '');
          await saveAnswer(userId, 'city', ocr.employee_city || '');
          await saveAnswer(userId, 'state', ocr.employee_state || '');
          await saveAnswer(userId, 'zip', ocr.employee_zip || '');
        }
        
        await saveAnswer(userId, 'documents_uploaded', true);
        await saveAnswer(userId, 'pending_w_2_confirm', cnt);
        
        result = { success: true, owner: 'taxpayer', type: 'W-2', num: cnt, employer: ocr.employer_name, wages: ocr.wages_tips_other_comp, withheld: ocr.federal_income_tax_withheld };
        console.log(`[UPLOAD] ✅ TAXPAYER W-2 #${cnt}: $${ocr.wages_tips_other_comp}`);
      }
      
    } else if (formType === '1099-INT') {
      if (forceSpouse) {
        const cnt = (parseInt(a.get('spouse_int_count')) || 0) + 1;
        await saveAnswer(userId, `spouse_int_${cnt}_raw`, JSON.stringify(ocr));
        await saveAnswer(userId, `spouse_int_${cnt}_payer`, ocr.payer_name);
        await saveAnswer(userId, `spouse_int_${cnt}_interest`, ocr.interest_income);
        const prev = parseFloat(a.get('spouse_total_interest')) || 0;
        await saveAnswer(userId, 'spouse_total_interest', prev + (ocr.interest_income || 0));
        await saveAnswer(userId, 'spouse_int_count', cnt);
        await saveAnswer(userId, 'spouse_1099_uploaded', 'yes');
        result = { success: true, owner: 'spouse', type: '1099-INT', payer: ocr.payer_name, interest: ocr.interest_income };
        console.log(`[UPLOAD] ✅ SPOUSE 1099-INT: $${ocr.interest_income}`);
      } else {
        const cnt = (parseInt(a.get('int_count')) || 0) + 1;
        await saveAnswer(userId, `int_${cnt}_raw`, JSON.stringify(ocr));
        await saveAnswer(userId, `int_${cnt}_payer`, ocr.payer_name);
        await saveAnswer(userId, `int_${cnt}_interest`, ocr.interest_income);
        await saveAnswer(userId, `int_${cnt}_confirmed`, false);
        const prev = parseFloat(a.get('total_interest')) || 0;
        await saveAnswer(userId, 'total_interest', prev + (ocr.interest_income || 0));
        await saveAnswer(userId, 'int_count', cnt);
        await saveAnswer(userId, 'documents_uploaded', true);
        await saveAnswer(userId, 'pending_1099_int_confirm', cnt);
        result = { success: true, owner: 'taxpayer', type: '1099-INT', num: cnt, payer: ocr.payer_name, interest: ocr.interest_income };
        console.log(`[UPLOAD] ✅ TAXPAYER 1099-INT #${cnt}: $${ocr.interest_income}`);
      }
      
    } else if (formType === '1099-NEC') {
      const cnt = (parseInt(a.get('nec_count')) || 0) + 1;
      await saveAnswer(userId, `nec_${cnt}_raw`, JSON.stringify(ocr));
      await saveAnswer(userId, `nec_${cnt}_payer`, ocr.payer_name);
      await saveAnswer(userId, `nec_${cnt}_income`, ocr.nonemployee_compensation);
      const prev = parseFloat(a.get('total_self_employment')) || 0;
      await saveAnswer(userId, 'total_self_employment', prev + (ocr.nonemployee_compensation || 0));
      await saveAnswer(userId, 'nec_count', cnt);
      await saveAnswer(userId, 'documents_uploaded', true);
      result = { success: true, type: '1099-NEC', num: cnt, payer: ocr.payer_name, income: ocr.nonemployee_compensation };
      console.log(`[UPLOAD] ✅ 1099-NEC #${cnt}: $${ocr.nonemployee_compensation}`);
      
    } else if (formType === '1099-DIV') {
      const cnt = (parseInt(a.get('div_count')) || 0) + 1;
      await saveAnswer(userId, `div_${cnt}_raw`, JSON.stringify(ocr));
      await saveAnswer(userId, `div_${cnt}_payer`, ocr.payer_name);
      await saveAnswer(userId, `div_${cnt}_ordinary`, ocr.ordinary_dividends);
      const prev = parseFloat(a.get('total_dividends')) || 0;
      await saveAnswer(userId, 'total_dividends', prev + (ocr.ordinary_dividends || 0));
      await saveAnswer(userId, 'div_count', cnt);
      await saveAnswer(userId, 'documents_uploaded', true);
      result = { success: true, type: '1099-DIV', num: cnt, payer: ocr.payer_name, dividends: ocr.ordinary_dividends };
      console.log(`[UPLOAD] ✅ 1099-DIV #${cnt}: $${ocr.ordinary_dividends}`);
    }
    
    return res.json(result);
    
  } catch (e) {
    console.error("[UPLOAD] Error:", e);
    return res.status(500).json({ error: e.message });
  }
});

router.get("/status", async (req, res) => {
  try {
    const s = await getSession(req.query.userId);
    const a = s.answers || new Map();
    res.json({
      taxpayer: { w2: parseInt(a.get('w2_count'))||0, wages: parseFloat(a.get('total_wages'))||0, int: parseInt(a.get('int_count'))||0, interest: parseFloat(a.get('total_interest'))||0 },
      spouse: { w2: parseInt(a.get('spouse_w2_count'))||0, wages: parseFloat(a.get('spouse_total_wages'))||0, int: parseInt(a.get('spouse_int_count'))||0, interest: parseFloat(a.get('spouse_total_interest'))||0 },
      confirmed: a.get('documents_confirmed') === 'yes'
    });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

export default router;
// ============================================================
// CPA ADMIN PAGE - Manage CPA Users
// ============================================================
// Location: frontend/src/pages/CPAAdmin.jsx
// ============================================================

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { cpaAPI } from '../services/cpaAPI';
import { useCPAAuth } from '../contexts/CPAAuthContext';

export default function CPAAdmin() {
  const navigate = useNavigate();
  const { cpa, logout } = useCPAAuth();
  
  const [cpas, setCPAs] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Filters
  const [statusFilter, setStatusFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');
  const [search, setSearch] = useState('');

  // Check admin access
  useEffect(() => {
    if (cpa && !['admin', 'senior_cpa'].includes(cpa.role)) {
      navigate('/cpa/dashboard');
    }
  }, [cpa, navigate]);

  // Load data
  useEffect(() => {
    loadData();
  }, [statusFilter, roleFilter, search]);

  async function loadData() {
    try {
      setLoading(true);
      const [cpasRes, statsRes] = await Promise.all([
        cpaAPI.getAllCPAs({ status: statusFilter, role: roleFilter, search }),
        cpaAPI.getCPAStats()
      ]);
      
      if (cpasRes.success) setCPAs(cpasRes.cpas);
      if (statsRes.success) setStats(statsRes);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  // Approve CPA
  async function handleApprove(cpaId) {
    try {
      const res = await cpaAPI.approveCPA(cpaId);
      if (res.success) {
        loadData();
      }
    } catch (err) {
      setError(err.message);
    }
  }

  // Update status
  async function handleUpdateStatus(cpaId, newStatus) {
    try {
      const res = await cpaAPI.updateCPAStatus(cpaId, newStatus);
      if (res.success) {
        loadData();
      }
    } catch (err) {
      setError(err.message);
    }
  }

  // Update role
  async function handleUpdateRole(cpaId, newRole) {
    try {
      const res = await cpaAPI.updateCPAPermissions(cpaId, null, newRole);
      if (res.success) {
        loadData();
      }
    } catch (err) {
      setError(err.message);
    }
  }

  // Get status badge
  function getStatusBadge(status) {
    const badges = {
      active: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      suspended: 'bg-red-100 text-red-800',
      inactive: 'bg-gray-100 text-gray-800'
    };
    return badges[status] || 'bg-gray-100 text-gray-800';
  }

  // Get role badge
  function getRoleBadge(role) {
    const badges = {
      admin: 'bg-purple-100 text-purple-800',
      senior_cpa: 'bg-blue-100 text-blue-800',
      cpa: 'bg-gray-100 text-gray-800'
    };
    return badges[role] || 'bg-gray-100 text-gray-800';
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              CPA Management
            </h1>
            <p className="text-sm text-gray-500">
              Admin Portal - {cpa?.firstName} {cpa?.lastName}
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate('/cpa/dashboard')}
              className="text-blue-600 hover:underline"
            >
              Back to Dashboard
            </button>
            <button
              onClick={() => { logout(); navigate('/cpa/login'); }}
              className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Error */}
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            Error: {error}
            <button onClick={() => setError(null)} className="float-right font-bold">X</button>
          </div>
        )}

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow p-4">
              <p className="text-gray-500 text-sm">Total CPAs</p>
              <p className="text-2xl font-bold">
                {(stats.statusCounts?.active || 0) + 
                 (stats.statusCounts?.pending || 0) + 
                 (stats.statusCounts?.suspended || 0)}
              </p>
            </div>
            <div className="bg-green-50 rounded-lg shadow p-4 border-l-4 border-green-500">
              <p className="text-gray-500 text-sm">Active</p>
              <p className="text-2xl font-bold text-green-600">{stats.statusCounts?.active || 0}</p>
            </div>
            <div className="bg-yellow-50 rounded-lg shadow p-4 border-l-4 border-yellow-500">
              <p className="text-gray-500 text-sm">Pending Approval</p>
              <p className="text-2xl font-bold text-yellow-600">{stats.statusCounts?.pending || 0}</p>
            </div>
            <div className="bg-red-50 rounded-lg shadow p-4 border-l-4 border-red-500">
              <p className="text-gray-500 text-sm">Suspended</p>
              <p className="text-2xl font-bold text-red-600">{stats.statusCounts?.suspended || 0}</p>
            </div>
          </div>
        )}

        {/* Filters */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex gap-4 items-center">
            {/* Search */}
            <div className="flex-1">
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, email, or license..."
                className="w-full border rounded px-4 py-2"
              />
            </div>
            
            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border rounded px-4 py-2"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="pending">Pending</option>
              <option value="suspended">Suspended</option>
              <option value="inactive">Inactive</option>
            </select>
            
            {/* Role Filter */}
            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="border rounded px-4 py-2"
            >
              <option value="all">All Roles</option>
              <option value="admin">Admin</option>
              <option value="senior_cpa">Senior CPA</option>
              <option value="cpa">CPA</option>
            </select>
          </div>
        </div>

        {/* CPA Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-2 text-gray-500">Loading...</p>
            </div>
          ) : cpas.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No CPAs found
            </div>
          ) : (
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">CPA</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">License</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Role</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Status</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Reviews</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Last Login</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {cpas.map((c) => (
                  <tr key={c._id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div>
                        <p className="font-medium">{c.firstName} {c.lastName}</p>
                        <p className="text-sm text-gray-500">{c.email}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-sm">{c.licenseNumber}</span>
                      <span className="text-gray-400 ml-1">({c.licenseState})</span>
                    </td>
                    <td className="px-4 py-3">
                      {cpa.role === 'admin' && c._id !== cpa.id ? (
                        <select
                          value={c.role}
                          onChange={(e) => handleUpdateRole(c._id, e.target.value)}
                          className={`px-2 py-1 rounded text-xs font-medium border-0 cursor-pointer ${getRoleBadge(c.role)}`}
                        >
                          <option value="cpa">CPA</option>
                          <option value="senior_cpa">Senior CPA</option>
                          <option value="admin">Admin</option>
                        </select>
                      ) : (
                        <span className={`px-2 py-1 rounded text-xs font-medium ${getRoleBadge(c.role)}`}>
                          {c.role.replace('_', ' ').toUpperCase()}
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusBadge(c.status)}`}>
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm">
                      <span className="text-green-600 font-medium">{c.stats?.totalApproved || 0}</span>
                      <span className="text-gray-400 mx-1">/</span>
                      <span className="text-red-600 font-medium">{c.stats?.totalRejected || 0}</span>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-500">
                      {c.lastLoginAt 
                        ? new Date(c.lastLoginAt).toLocaleDateString()
                        : 'Never'}
                    </td>
                    <td className="px-4 py-3">
                      {c._id !== cpa.id && cpa.role === 'admin' && (
                        <div className="flex gap-2">
                          {c.status === 'pending' && (
                            <button
                              onClick={() => handleApprove(c._id)}
                              className="bg-green-100 text-green-700 px-3 py-1 rounded text-sm hover:bg-green-200"
                            >
                              Approve
                            </button>
                          )}
                          {c.status === 'active' && (
                            <button
                              onClick={() => handleUpdateStatus(c._id, 'suspended')}
                              className="bg-red-100 text-red-700 px-3 py-1 rounded text-sm hover:bg-red-200"
                            >
                              Suspend
                            </button>
                          )}
                          {c.status === 'suspended' && (
                            <button
                              onClick={() => handleUpdateStatus(c._id, 'active')}
                              className="bg-green-100 text-green-700 px-3 py-1 rounded text-sm hover:bg-green-200"
                            >
                              Reactivate
                            </button>
                          )}
                        </div>
                      )}
                      {c._id === cpa.id && (
                        <span className="text-gray-400 text-sm italic">You</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Leaderboard */}
        {stats?.leaderboard && stats.leaderboard.length > 0 && (
          <div className="mt-6 bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Top Reviewers (Last 30 Days)</h3>
            <div className="space-y-2">
              {stats.leaderboard.map((reviewer, index) => (
                <div key={reviewer._id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center gap-3">
                    <span className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                      index === 0 ? 'bg-yellow-500' : 
                      index === 1 ? 'bg-gray-400' : 
                      index === 2 ? 'bg-orange-400' : 'bg-gray-300'
                    }`}>
                      {index + 1}
                    </span>
                    <span className="font-medium">{reviewer._id}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-blue-600 text-lg">{reviewer.total}</span>
                    <span className="text-gray-400 text-sm ml-1">reviews</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
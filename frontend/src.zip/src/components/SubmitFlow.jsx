// ============================================================
// SUBMIT FLOW - Multi-Language Support
// ============================================================
// Location: frontend/src/components/SubmitFlow.jsx
// Flow: Review → Verify → Check Refund → Sign → PAY → File
// ============================================================

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../contexts/LanguageContext';

const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:3000";

// ============================================================
// TRANSLATIONS
// ============================================================
const submitFlowTranslations = {
  en: {
    title: "📋 File Your Tax Return",
    taxYear: "Tax Year 2024",
    
    // Steps
    steps: {
      reviewInfo: "Review Info",
      verifyIncome: "Verify Income",
      checkRefund: "Check Refund",
      confirmSign: "Confirm & Sign",
      complete: "Complete"
    },
    
    // Step 1
    step1: {
      title: "👤 Review Your Information",
      missingInfo: "⚠️ Missing Information",
      clickEdit: "👆 Click Edit to add the missing information.",
      edit: "✏️ Edit",
      personalInfo: "Personal Information",
      name: "Name",
      ssn: "SSN",
      address: "Address",
      filingStatus: "Filing Status",
      notSelected: "Not selected"
    },
    
    // Step 2
    step2: {
      title: "💰 Verify Your Income",
      w2Wages: "W-2 Wages",
      income1099: "1099 Income",
      otherIncome: "Other Income",
      totalIncome: "Total Income",
      taxWithheld: "Tax Withheld",
      federalWithheld: "Federal Withheld",
      stateWithheld: "State Withheld"
    },
    
    // Step 3
    step3: {
      title: "🎯 Your Tax Summary",
      estimatedRefund: "💰 Estimated Total Refund",
      estimatedOwed: "💸 Estimated Amount Owed",
      federal: "🇺🇸 Federal",
      state: "🌴 California",
      childTaxCredit: "👶 Child Tax Credit"
    },
    
    // Step 4
    step4: {
      title: "✍️ Confirm & Sign",
      declaration: "Under penalties of perjury, I declare that I have examined this return and accompanying schedules and statements, and to the best of my knowledge and belief, they are true, correct, and complete.",
      signatureLabel: "Your Signature (Type Full Name)",
      dateLabel: "Date",
      agreeTerms: "I agree to the terms and conditions and authorize TaxSky to file my tax return."
    },
    
    // Step 5 - Payment
    step5: {
      loadingPayment: "Loading payment options...",
      paymentComplete: "Payment Complete!",
      cpaReviewIncluded: "CPA Review Included",
      cpaReviewDesc: "A CPA will review your return within 24-48 hours before filing.",
      fileToIRS: "📤 File to IRS",
      filing: "Filing...",
      completeYourFiling: "💳 Complete Your Filing",
      choosePlan: "Choose your plan to file your taxes",
      standardFiling: "Standard Filing",
      fileToIRSDesc: "File to IRS",
      premiumCPA: "Premium + CPA",
      cpaReviewsFirst: "CPA reviews first",
      cpaReview: "⭐ CPA REVIEW",
      features: {
        federalReturn: "Federal Return",
        stateReturn: "State Return",
        eFile: "E-File to IRS",
        downloadPDF: "Download PDF",
        everythingStandard: "Everything Standard",
        cpaReview: "CPA Review",
        auditProtection: "Audit Protection",
        prioritySupport: "Priority Support"
      },
      selectedPlan: "Selected Plan",
      total: "Total"
    },
    
    // Step 6 - Complete
    step6: {
      cpaReviewTitle: "Submitted for CPA Review!",
      cpaReviewDesc: "Your return has been submitted for CPA review. A certified accountant will review your return within 24-48 hours. You'll receive an email when it's ready to file.",
      filedTitle: "Tax Return Filed!",
      filedDesc: "Your tax return has been successfully submitted to the IRS. You'll receive a confirmation email shortly.",
      confirmationNumber: "Confirmation Number",
      done: "Done"
    },
    
    // Buttons
    buttons: {
      cancel: "Cancel",
      back: "← Back",
      continue: "Continue →",
      proceedToPayment: "💳 Proceed to Payment"
    },
    
    // Missing fields
    fields: {
      first_name: "First Name",
      last_name: "Last Name",
      ssn: "Social Security Number",
      address: "Address",
      city: "City",
      state: "State",
      zip: "ZIP Code",
      filing_status: "Filing Status"
    }
  },
  
  vi: {
    title: "📋 Nộp Tờ Khai Thuế",
    taxYear: "Năm Thuế 2024",
    
    steps: {
      reviewInfo: "Xem Thông Tin",
      verifyIncome: "Xác Nhận Thu Nhập",
      checkRefund: "Kiểm Tra Hoàn Thuế",
      confirmSign: "Xác Nhận & Ký",
      complete: "Hoàn Tất"
    },
    
    step1: {
      title: "👤 Xem Lại Thông Tin",
      missingInfo: "⚠️ Thiếu Thông Tin",
      clickEdit: "👆 Nhấn Sửa để thêm thông tin còn thiếu.",
      edit: "✏️ Sửa",
      personalInfo: "Thông Tin Cá Nhân",
      name: "Họ Tên",
      ssn: "Số An Sinh",
      address: "Địa Chỉ",
      filingStatus: "Tình Trạng Khai Thuế",
      notSelected: "Chưa chọn"
    },
    
    step2: {
      title: "💰 Xác Nhận Thu Nhập",
      w2Wages: "Lương W-2",
      income1099: "Thu Nhập 1099",
      otherIncome: "Thu Nhập Khác",
      totalIncome: "Tổng Thu Nhập",
      taxWithheld: "Thuế Đã Khấu Trừ",
      federalWithheld: "Thuế LB Đã Khấu Trừ",
      stateWithheld: "Thuế TB Đã Khấu Trừ"
    },
    
    step3: {
      title: "🎯 Tóm Tắt Thuế",
      estimatedRefund: "💰 Ước Tính Hoàn Thuế",
      estimatedOwed: "💸 Ước Tính Nợ Thuế",
      federal: "🇺🇸 Liên Bang",
      state: "🌴 California",
      childTaxCredit: "👶 Tín Dụng Trẻ Em"
    },
    
    step4: {
      title: "✍️ Xác Nhận & Ký",
      declaration: "Dưới hình phạt khai man, tôi tuyên bố rằng tôi đã kiểm tra tờ khai này và các biểu mẫu kèm theo, và theo hiểu biết tốt nhất của tôi, chúng là đúng sự thật, chính xác và đầy đủ.",
      signatureLabel: "Chữ Ký (Gõ Họ Tên Đầy Đủ)",
      dateLabel: "Ngày",
      agreeTerms: "Tôi đồng ý với các điều khoản và cho phép TaxSky nộp tờ khai thuế của tôi."
    },
    
    step5: {
      loadingPayment: "Đang tải tùy chọn thanh toán...",
      paymentComplete: "Thanh Toán Hoàn Tất!",
      cpaReviewIncluded: "Bao Gồm Xem Xét CPA",
      cpaReviewDesc: "CPA sẽ xem xét tờ khai của bạn trong 24-48 giờ trước khi nộp.",
      fileToIRS: "📤 Nộp Cho IRS",
      filing: "Đang nộp...",
      completeYourFiling: "💳 Hoàn Tất Khai Thuế",
      choosePlan: "Chọn gói để nộp thuế",
      standardFiling: "Gói Tiêu Chuẩn",
      fileToIRSDesc: "Nộp cho IRS",
      premiumCPA: "Premium + CPA",
      cpaReviewsFirst: "CPA xem xét trước",
      cpaReview: "⭐ XEM XÉT CPA",
      features: {
        federalReturn: "Khai thuế Liên Bang",
        stateReturn: "Khai thuế Tiểu Bang",
        eFile: "E-File cho IRS",
        downloadPDF: "Tải PDF",
        everythingStandard: "Tất cả gói Tiêu Chuẩn",
        cpaReview: "CPA Xem Xét",
        auditProtection: "Bảo Vệ Kiểm Toán",
        prioritySupport: "Hỗ Trợ Ưu Tiên"
      },
      selectedPlan: "Gói Đã Chọn",
      total: "Tổng Cộng"
    },
    
    step6: {
      cpaReviewTitle: "Đã Gửi Để CPA Xem Xét!",
      cpaReviewDesc: "Tờ khai của bạn đã được gửi để CPA xem xét. Kế toán công chứng sẽ xem xét trong 24-48 giờ. Bạn sẽ nhận email khi sẵn sàng nộp.",
      filedTitle: "Đã Nộp Tờ Khai Thuế!",
      filedDesc: "Tờ khai thuế của bạn đã được nộp thành công cho IRS. Bạn sẽ nhận email xác nhận sớm.",
      confirmationNumber: "Số Xác Nhận",
      done: "Xong"
    },
    
    buttons: {
      cancel: "Hủy",
      back: "← Quay Lại",
      continue: "Tiếp Tục →",
      proceedToPayment: "💳 Tiến Hành Thanh Toán"
    },
    
    fields: {
      first_name: "Tên",
      last_name: "Họ",
      ssn: "Số An Sinh Xã Hội",
      address: "Địa Chỉ",
      city: "Thành Phố",
      state: "Tiểu Bang",
      zip: "Mã Bưu Điện",
      filing_status: "Tình Trạng Khai Thuế"
    }
  },
  
  es: {
    title: "📋 Presentar Tu Declaración",
    taxYear: "Año Fiscal 2024",
    
    steps: {
      reviewInfo: "Revisar Info",
      verifyIncome: "Verificar Ingresos",
      checkRefund: "Ver Reembolso",
      confirmSign: "Confirmar y Firmar",
      complete: "Completar"
    },
    
    step1: {
      title: "👤 Revisa Tu Información",
      missingInfo: "⚠️ Información Faltante",
      clickEdit: "👆 Haz clic en Editar para agregar la información faltante.",
      edit: "✏️ Editar",
      personalInfo: "Información Personal",
      name: "Nombre",
      ssn: "Número de Seguro Social",
      address: "Dirección",
      filingStatus: "Estado Civil Tributario",
      notSelected: "No seleccionado"
    },
    
    step2: {
      title: "💰 Verifica Tus Ingresos",
      w2Wages: "Salarios W-2",
      income1099: "Ingresos 1099",
      otherIncome: "Otros Ingresos",
      totalIncome: "Ingreso Total",
      taxWithheld: "Impuesto Retenido",
      federalWithheld: "Retención Federal",
      stateWithheld: "Retención Estatal"
    },
    
    step3: {
      title: "🎯 Tu Resumen Fiscal",
      estimatedRefund: "💰 Reembolso Estimado",
      estimatedOwed: "💸 Cantidad Adeudada",
      federal: "🇺🇸 Federal",
      state: "🌴 California",
      childTaxCredit: "👶 Crédito por Hijos"
    },
    
    step4: {
      title: "✍️ Confirmar y Firmar",
      declaration: "Bajo pena de perjurio, declaro que he examinado esta declaración y los anexos adjuntos, y según mi leal saber y entender, son verdaderos, correctos y completos.",
      signatureLabel: "Tu Firma (Escribe Nombre Completo)",
      dateLabel: "Fecha",
      agreeTerms: "Acepto los términos y autorizo a TaxSky a presentar mi declaración."
    },
    
    step5: {
      loadingPayment: "Cargando opciones de pago...",
      paymentComplete: "¡Pago Completado!",
      cpaReviewIncluded: "Revisión de CPA Incluida",
      cpaReviewDesc: "Un CPA revisará tu declaración en 24-48 horas antes de presentar.",
      fileToIRS: "📤 Presentar al IRS",
      filing: "Presentando...",
      completeYourFiling: "💳 Completa Tu Declaración",
      choosePlan: "Elige tu plan para declarar",
      standardFiling: "Declaración Estándar",
      fileToIRSDesc: "Presentar al IRS",
      premiumCPA: "Premium + CPA",
      cpaReviewsFirst: "CPA revisa primero",
      cpaReview: "⭐ REVISIÓN CPA",
      features: {
        federalReturn: "Declaración Federal",
        stateReturn: "Declaración Estatal",
        eFile: "E-File al IRS",
        downloadPDF: "Descargar PDF",
        everythingStandard: "Todo lo Estándar",
        cpaReview: "Revisión CPA",
        auditProtection: "Protección de Auditoría",
        prioritySupport: "Soporte Prioritario"
      },
      selectedPlan: "Plan Seleccionado",
      total: "Total"
    },
    
    step6: {
      cpaReviewTitle: "¡Enviado para Revisión CPA!",
      cpaReviewDesc: "Tu declaración ha sido enviada para revisión de CPA. Un contador certificado la revisará en 24-48 horas. Recibirás un email cuando esté lista.",
      filedTitle: "¡Declaración Presentada!",
      filedDesc: "Tu declaración ha sido enviada exitosamente al IRS. Recibirás un email de confirmación pronto.",
      confirmationNumber: "Número de Confirmación",
      done: "Listo"
    },
    
    buttons: {
      cancel: "Cancelar",
      back: "← Atrás",
      continue: "Continuar →",
      proceedToPayment: "💳 Proceder al Pago"
    },
    
    fields: {
      first_name: "Nombre",
      last_name: "Apellido",
      ssn: "Número de Seguro Social",
      address: "Dirección",
      city: "Ciudad",
      state: "Estado",
      zip: "Código Postal",
      filing_status: "Estado Civil Tributario"
    }
  }
};

export default function SubmitFlow({ onClose, taxData, userData }) {
  const navigate = useNavigate();
  const { lang } = useLanguage();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [signature, setSignature] = useState('');
  const [signatureDate, setSignatureDate] = useState(new Date().toLocaleDateString());
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  
  // Payment state
  const [hasPaid, setHasPaid] = useState(false);
  const [payment, setPayment] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState('standard');
  const [recommendedPlan, setRecommendedPlan] = useState(null);
  const [filingComplete, setFilingComplete] = useState(false);
  
  // Get translations
  const t = submitFlowTranslations[lang] || submitFlowTranslations.en;
  
  const user = JSON.parse(localStorage.getItem('taxsky_user') || '{}');
  const token = localStorage.getItem('taxsky_token');
  const userId = user.id || user.userId;

  // Check payment status when reaching step 5
  useEffect(() => {
    if (step === 5) {
      checkPaymentStatus();
    }
  }, [step]);

  async function checkPaymentStatus() {
    try {
      setLoading(true);
      
      const statusRes = await fetch(`${API_BASE}/api/payments/status/${userId}/2024`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const statusData = await statusRes.json();
      
      if (statusData.hasPaid) {
        setHasPaid(true);
        setPayment(statusData.payment);
      } else {
        const recRes = await fetch(`${API_BASE}/api/payments/recommend/${userId}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const recData = await recRes.json();
        if (recData.success) {
          setRecommendedPlan(recData);
        }
      }
    } catch (error) {
      console.error('Error checking payment:', error);
    } finally {
      setLoading(false);
    }
  }

  function getMissingFields() {
    const required = [
      { key: 'first_name', label: t.fields.first_name },
      { key: 'last_name', label: t.fields.last_name },
      { key: 'ssn', label: t.fields.ssn },
      { key: 'address', label: t.fields.address },
      { key: 'city', label: t.fields.city },
      { key: 'state', label: t.fields.state },
      { key: 'zip', label: t.fields.zip },
      { key: 'filing_status', label: t.fields.filing_status },
    ];
    
    return required.filter(f => !userData?.[f.key]);
  }

  const missingFields = getMissingFields();
  const isComplete = missingFields.length === 0;

  const fmt = (num) => {
    if (!num && num !== 0) return '$0';
    return '$' + Math.abs(Math.round(num)).toLocaleString();
  };

  const federalNet = (taxData?.federalRefund || 0) - (taxData?.federalOwed || 0);
  const stateNet = (taxData?.stateRefund || 0) - (taxData?.stateOwed || 0);
  const totalNet = federalNet + stateNet;

  function handleProceedToPayment() {
    const planId = selectedPlan === 'premium' ? 'premium' : (recommendedPlan?.recommendedPlan || 'single_simple');
    localStorage.setItem('payment_return_to', '/dashboard');
    navigate(`/payment/checkout/${planId}`);
  }

  async function handleFileToIRS() {
    try {
      setLoading(true);
      
      if (payment?.planId === 'premium') {
        await fetch(`${API_BASE}/api/tax/submit-for-review`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}` 
          },
          body: JSON.stringify({ 
            userId, 
            taxYear: 2024,
            signature,
            requireCpaReview: true
          })
        });
        
        setFilingComplete(true);
        setStep(6);
      } else {
        const res = await fetch(`${API_BASE}/api/tax/file-to-irs`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}` 
          },
          body: JSON.stringify({ 
            userId, 
            taxYear: 2024,
            signature 
          })
        });
        
        const data = await res.json();
        if (data.success) {
          setFilingComplete(true);
          setStep(6);
        } else {
          alert(data.error || 'Filing failed. Please try again.');
        }
      }
    } catch (error) {
      console.error('Filing error:', error);
      alert('Error filing return. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const steps = [
    { num: 1, title: t.steps.reviewInfo },
    { num: 2, title: t.steps.verifyIncome },
    { num: 3, title: t.steps.checkRefund },
    { num: 4, title: t.steps.confirmSign },
    { num: 5, title: t.steps.complete }
  ];

  return (
    <div style={styles.overlay}>
      <div style={styles.modal}>
        {/* Header */}
        <div style={styles.header}>
          <div>
            <h2 style={styles.headerTitle}>{t.title}</h2>
            <p style={styles.headerSubtitle}>{t.taxYear}</p>
          </div>
          <button onClick={onClose} style={styles.closeBtn}>×</button>
        </div>

        {/* Step Indicator */}
        {step <= 5 && (
          <div style={styles.stepIndicator}>
            {steps.map((s, i) => (
              <React.Fragment key={s.num}>
                <div style={styles.stepItem}>
                  <div style={{
                    ...styles.stepCircle,
                    backgroundColor: step >= s.num ? '#7c3aed' : '#e2e8f0',
                    color: step >= s.num ? 'white' : '#64748b'
                  }}>
                    {step > s.num ? '✓' : s.num}
                  </div>
                  <span style={{
                    ...styles.stepLabel,
                    color: step >= s.num ? '#1e293b' : '#94a3b8'
                  }}>{s.title}</span>
                </div>
                {i < steps.length - 1 && (
                  <div style={{
                    ...styles.stepLine,
                    backgroundColor: step > s.num ? '#7c3aed' : '#e2e8f0'
                  }} />
                )}
              </React.Fragment>
            ))}
          </div>
        )}

        {/* Content */}
        <div style={styles.content}>
          {/* STEP 1: Review Info */}
          {step === 1 && (
            <div>
              <h3 style={styles.sectionTitle}>{t.step1.title}</h3>
              
              {missingFields.length > 0 && (
                <div style={styles.warningBox}>
                  <h4 style={styles.warningTitle}>{t.step1.missingInfo}</h4>
                  <ul style={styles.missingList}>
                    {missingFields.map((f, i) => (
                      <li key={i} style={styles.missingItem}>• {f.label}</li>
                    ))}
                  </ul>
                  <p style={styles.warningNote}>{t.step1.clickEdit}</p>
                  <button 
                    onClick={() => navigate('/taxchat')}
                    style={styles.editBtn}
                  >
                    {t.step1.edit}
                  </button>
                </div>
              )}

              <div style={styles.infoCard}>
                <h4 style={styles.infoTitle}>{t.step1.personalInfo}</h4>
                <div style={styles.infoGrid}>
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>{t.step1.name}:</span>
                    <span style={styles.infoValue}>{userData?.first_name} {userData?.last_name}</span>
                  </div>
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>{t.step1.ssn}:</span>
                    <span style={styles.infoValue}>***-**-{String(userData?.ssn || '').slice(-4)}</span>
                  </div>
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>{t.step1.address}:</span>
                    <span style={styles.infoValue}>{userData?.address}, {userData?.city}, {userData?.state} {userData?.zip}</span>
                  </div>
                  <div style={styles.infoRow}>
                    <span style={styles.infoLabel}>{t.step1.filingStatus}:</span>
                    <span style={styles.infoValue}>{userData?.filing_status?.replace(/_/g, ' ') || t.step1.notSelected}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: Verify Income */}
          {step === 2 && (
            <div>
              <h3 style={styles.sectionTitle}>{t.step2.title}</h3>
              
              <div style={styles.incomeCard}>
                <div style={styles.incomeRow}>
                  <span>{t.step2.w2Wages}</span>
                  <span style={styles.incomeValue}>{fmt(taxData?.totalIncome)}</span>
                </div>
                <div style={styles.incomeRow}>
                  <span>{t.step2.income1099}</span>
                  <span style={styles.incomeValue}>{fmt(taxData?.income1099 || 0)}</span>
                </div>
                <div style={styles.incomeRow}>
                  <span>{t.step2.otherIncome}</span>
                  <span style={styles.incomeValue}>{fmt(taxData?.otherIncome || 0)}</span>
                </div>
                <hr style={styles.divider} />
                <div style={styles.incomeTotal}>
                  <span>{t.step2.totalIncome}</span>
                  <span>{fmt(taxData?.totalIncome)}</span>
                </div>
              </div>

              <div style={styles.withheldCard}>
                <h4>{t.step2.taxWithheld}</h4>
                <div style={styles.incomeRow}>
                  <span>{t.step2.federalWithheld}</span>
                  <span style={{ color: '#22c55e' }}>{fmt(taxData?.withholding)}</span>
                </div>
                <div style={styles.incomeRow}>
                  <span>{t.step2.stateWithheld}</span>
                  <span style={{ color: '#22c55e' }}>{fmt(taxData?.caWithholding)}</span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: Check Refund */}
          {step === 3 && (
            <div>
              <h3 style={styles.sectionTitle}>{t.step3.title}</h3>
              
              <div style={{
                ...styles.refundCard,
                backgroundColor: totalNet >= 0 ? '#f0fdf4' : '#fef2f2',
                borderColor: totalNet >= 0 ? '#22c55e' : '#ef4444'
              }}>
                <p style={styles.refundLabel}>
                  {totalNet >= 0 ? t.step3.estimatedRefund : t.step3.estimatedOwed}
                </p>
                <p style={{
                  ...styles.refundAmount,
                  color: totalNet >= 0 ? '#166534' : '#dc2626'
                }}>
                  {fmt(totalNet)}
                </p>
                <div style={styles.refundBreakdown}>
                  <div>
                    <span>{t.step3.federal}</span>
                    <strong style={{ color: federalNet >= 0 ? '#22c55e' : '#ef4444' }}>
                      {federalNet >= 0 ? '' : '-'}{fmt(federalNet)}
                    </strong>
                  </div>
                  <div>
                    <span>{t.step3.state}</span>
                    <strong style={{ color: stateNet >= 0 ? '#22c55e' : '#ef4444' }}>
                      {stateNet >= 0 ? '' : '-'}{fmt(stateNet)}
                    </strong>
                  </div>
                </div>
              </div>

              {taxData?.childTaxCredit > 0 && (
                <div style={styles.creditCard}>
                  <span>{t.step3.childTaxCredit}</span>
                  <span style={{ color: '#22c55e' }}>{fmt(taxData.childTaxCredit)}</span>
                </div>
              )}
            </div>
          )}

          {/* STEP 4: Confirm & Sign */}
          {step === 4 && (
            <div>
              <h3 style={styles.sectionTitle}>{t.step4.title}</h3>
              
              <div style={styles.signatureBox}>
                <p style={styles.signatureText}>{t.step4.declaration}</p>

                <div style={styles.signatureInputGroup}>
                  <label style={styles.signatureLabel}>{t.step4.signatureLabel}</label>
                  <input
                    type="text"
                    value={signature}
                    onChange={(e) => setSignature(e.target.value)}
                    placeholder={`${userData?.first_name || ''} ${userData?.last_name || ''}`}
                    style={styles.signatureInput}
                  />
                </div>

                <div style={styles.signatureInputGroup}>
                  <label style={styles.signatureLabel}>{t.step4.dateLabel}</label>
                  <input
                    type="text"
                    value={signatureDate}
                    readOnly
                    style={{...styles.signatureInput, backgroundColor: '#f8fafc'}}
                  />
                </div>

                <label style={styles.checkboxLabel}>
                  <input
                    type="checkbox"
                    checked={agreedToTerms}
                    onChange={(e) => setAgreedToTerms(e.target.checked)}
                    style={styles.checkbox}
                  />
                  {t.step4.agreeTerms}
                </label>
              </div>
            </div>
          )}

          {/* STEP 5: Payment & Complete */}
          {step === 5 && (
            <div>
              {loading ? (
                <div style={styles.loadingBox}>
                  <div style={styles.spinner}></div>
                  <p>{t.step5.loadingPayment}</p>
                </div>
              ) : hasPaid ? (
                <div>
                  <div style={styles.paidSuccess}>
                    <span style={styles.paidIcon}>✅</span>
                    <h3 style={styles.paidTitle}>{t.step5.paymentComplete}</h3>
                    <p style={styles.paidPlan}>{payment?.planName}</p>
                    <p style={styles.paidAmount}>{fmt(payment?.amount)}</p>
                  </div>

                  {payment?.planId === 'premium' && (
                    <div style={styles.cpaNote}>
                      <span style={styles.cpaIcon}>👨‍💼</span>
                      <div>
                        <strong>{t.step5.cpaReviewIncluded}</strong>
                        <p>{t.step5.cpaReviewDesc}</p>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={handleFileToIRS}
                    disabled={loading}
                    style={styles.fileIrsBtn}
                  >
                    {loading ? t.step5.filing : t.step5.fileToIRS}
                  </button>
                </div>
              ) : (
                <div>
                  <h3 style={styles.sectionTitle}>{t.step5.completeYourFiling}</h3>
                  <p style={styles.paymentSubtitle}>{t.step5.choosePlan}</p>

                  <div style={styles.plansGrid}>
                    {/* Standard Plan */}
                    <div 
                      style={{
                        ...styles.planCard,
                        border: selectedPlan === 'standard' ? '3px solid #3b82f6' : '2px solid #e2e8f0'
                      }}
                      onClick={() => setSelectedPlan('standard')}
                    >
                      <div style={styles.planHeader}>
                        <span style={styles.planIcon}>📄</span>
                        <div>
                          <h4 style={styles.planName}>
                            {recommendedPlan?.planDetails?.name || t.step5.standardFiling}
                          </h4>
                          <p style={styles.planDesc}>{t.step5.fileToIRSDesc}</p>
                        </div>
                        <input 
                          type="radio" 
                          checked={selectedPlan === 'standard'}
                          onChange={() => setSelectedPlan('standard')}
                          style={styles.radio}
                        />
                      </div>
                      <div style={styles.planPrice}>
                        ${((recommendedPlan?.planDetails?.price || 1999) / 100).toFixed(2)}
                      </div>
                      <ul style={styles.planFeatures}>
                        <li>✓ {t.step5.features.federalReturn}</li>
                        <li>✓ {t.step5.features.stateReturn}</li>
                        <li>✓ {t.step5.features.eFile}</li>
                        <li>✓ {t.step5.features.downloadPDF}</li>
                      </ul>
                    </div>

                    {/* Premium + CPA Plan */}
                    <div 
                      style={{
                        ...styles.planCard,
                        border: selectedPlan === 'premium' ? '3px solid #7c3aed' : '2px solid #e2e8f0',
                        position: 'relative'
                      }}
                      onClick={() => setSelectedPlan('premium')}
                    >
                      <div style={styles.recommendedBadge}>{t.step5.cpaReview}</div>
                      <div style={styles.planHeader}>
                        <span style={styles.planIcon}>⭐</span>
                        <div>
                          <h4 style={styles.planName}>{t.step5.premiumCPA}</h4>
                          <p style={styles.planDesc}>{t.step5.cpaReviewsFirst}</p>
                        </div>
                        <input 
                          type="radio" 
                          checked={selectedPlan === 'premium'}
                          onChange={() => setSelectedPlan('premium')}
                          style={styles.radio}
                        />
                      </div>
                      <div style={styles.planPrice}>$79.99</div>
                      <ul style={styles.planFeatures}>
                        <li>✓ {t.step5.features.everythingStandard}</li>
                        <li style={{ color: '#7c3aed', fontWeight: '600' }}>✓ {t.step5.features.cpaReview}</li>
                        <li style={{ color: '#7c3aed', fontWeight: '600' }}>✓ {t.step5.features.auditProtection}</li>
                        <li>✓ {t.step5.features.prioritySupport}</li>
                      </ul>
                    </div>
                  </div>

                  {/* Total */}
                  <div style={styles.totalBox}>
                    <div style={styles.totalRow}>
                      <span>{t.step5.selectedPlan}:</span>
                      <span>{selectedPlan === 'premium' ? t.step5.premiumCPA : recommendedPlan?.planDetails?.name || t.step5.standardFiling}</span>
                    </div>
                    <div style={styles.totalFinal}>
                      <span>{t.step5.total}:</span>
                      <span style={styles.totalAmount}>
                        ${selectedPlan === 'premium' ? '79.99' : ((recommendedPlan?.planDetails?.price || 1999) / 100).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 6: Filing Complete */}
          {step === 6 && (
            <div style={styles.completeBox}>
              {payment?.planId === 'premium' ? (
                <>
                  <span style={styles.completeIcon}>👨‍💼</span>
                  <h3 style={styles.completeTitle}>{t.step6.cpaReviewTitle}</h3>
                  <p style={styles.completeText}>{t.step6.cpaReviewDesc}</p>
                </>
              ) : (
                <>
                  <span style={styles.completeIcon}>🎉</span>
                  <h3 style={styles.completeTitle}>{t.step6.filedTitle}</h3>
                  <p style={styles.completeText}>{t.step6.filedDesc}</p>
                  <div style={styles.confirmationBox}>
                    <p>{t.step6.confirmationNumber}:</p>
                    <strong>TXS-{Date.now().toString().slice(-8)}</strong>
                  </div>
                </>
              )}
              <button onClick={onClose} style={styles.doneBtn}>{t.step6.done}</button>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        {step <= 5 && (
          <div style={styles.footer}>
            <button
              onClick={() => step > 1 ? setStep(step - 1) : onClose()}
              style={styles.backBtn}
            >
              {step === 1 ? t.buttons.cancel : t.buttons.back}
            </button>

            {step < 5 && step !== 4 && (
              <button
                onClick={() => setStep(step + 1)}
                disabled={step === 1 && !isComplete}
                style={{
                  ...styles.nextBtn,
                  opacity: (step === 1 && !isComplete) ? 0.5 : 1,
                  cursor: (step === 1 && !isComplete) ? 'not-allowed' : 'pointer'
                }}
              >
                {t.buttons.continue}
              </button>
            )}

            {step === 4 && (
              <button
                onClick={() => setStep(5)}
                disabled={!signature || !agreedToTerms}
                style={{
                  ...styles.nextBtn,
                  opacity: (!signature || !agreedToTerms) ? 0.5 : 1,
                  cursor: (!signature || !agreedToTerms) ? 'not-allowed' : 'pointer'
                }}
              >
                {t.buttons.continue}
              </button>
            )}

            {step === 5 && !hasPaid && (
              <button
                onClick={handleProceedToPayment}
                style={styles.payBtn}
              >
                {t.buttons.proceedToPayment}
              </button>
            )}
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}

// ============================================================
// STYLES
// ============================================================
const styles = {
  overlay: {
    position: 'fixed',
    inset: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
    padding: '20px'
  },
  modal: {
    backgroundColor: 'white',
    borderRadius: '20px',
    maxWidth: '700px',
    width: '100%',
    maxHeight: '90vh',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '24px 32px',
    background: 'linear-gradient(135deg, #7c3aed 0%, #a855f7 100%)',
    color: 'white'
  },
  headerTitle: { margin: 0, fontSize: '24px' },
  headerSubtitle: { margin: '4px 0 0', opacity: 0.8, fontSize: '14px' },
  closeBtn: {
    background: 'rgba(255,255,255,0.2)',
    border: 'none',
    color: 'white',
    width: '36px',
    height: '36px',
    borderRadius: '50%',
    fontSize: '24px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  stepIndicator: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
    backgroundColor: '#f8fafc',
    borderBottom: '1px solid #e2e8f0'
  },
  stepItem: { display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' },
  stepCircle: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: '600',
    fontSize: '14px'
  },
  stepLabel: { fontSize: '12px', fontWeight: '500' },
  stepLine: { width: '40px', height: '3px', margin: '0 8px', borderRadius: '2px' },
  content: { padding: '32px', overflowY: 'auto', flex: 1 },
  sectionTitle: { marginTop: 0, marginBottom: '20px', color: '#1e293b' },
  warningBox: {
    backgroundColor: '#fef3c7',
    border: '2px solid #f59e0b',
    borderRadius: '12px',
    padding: '20px',
    marginBottom: '24px'
  },
  warningTitle: { margin: '0 0 12px', color: '#92400e' },
  missingList: { margin: '0 0 12px', paddingLeft: '0', listStyle: 'none' },
  missingItem: { color: '#b45309', marginBottom: '4px' },
  warningNote: { color: '#92400e', fontSize: '14px', marginBottom: '12px' },
  editBtn: {
    padding: '10px 20px',
    backgroundColor: '#f59e0b',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontWeight: '600',
    cursor: 'pointer'
  },
  infoCard: { backgroundColor: '#f8fafc', borderRadius: '12px', padding: '20px' },
  infoTitle: { marginTop: 0, marginBottom: '16px', color: '#475569' },
  infoGrid: { display: 'grid', gap: '12px' },
  infoRow: { display: 'flex', justifyContent: 'space-between' },
  infoLabel: { color: '#64748b' },
  infoValue: { fontWeight: '600' },
  incomeCard: {
    backgroundColor: '#f8fafc',
    borderRadius: '12px',
    padding: '20px',
    marginBottom: '20px'
  },
  incomeRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '8px 0'
  },
  incomeValue: { fontWeight: '600' },
  divider: { border: 'none', borderTop: '1px solid #e2e8f0', margin: '12px 0' },
  incomeTotal: {
    display: 'flex',
    justifyContent: 'space-between',
    fontWeight: '700',
    fontSize: '18px'
  },
  withheldCard: {
    backgroundColor: '#f0fdf4',
    borderRadius: '12px',
    padding: '20px'
  },
  refundCard: {
    borderRadius: '16px',
    padding: '32px',
    textAlign: 'center',
    border: '3px solid',
    marginBottom: '16px'
  },
  refundLabel: { fontSize: '16px', marginBottom: '8px' },
  refundAmount: { fontSize: '48px', fontWeight: '800', margin: '8px 0 24px' },
  refundBreakdown: { display: 'flex', justifyContent: 'center', gap: '48px' },
  creditCard: {
    display: 'flex',
    justifyContent: 'space-between',
    backgroundColor: '#f0fdf4',
    borderRadius: '12px',
    padding: '16px 20px',
    fontWeight: '600'
  },
  signatureBox: { backgroundColor: '#f8fafc', borderRadius: '12px', padding: '24px' },
  signatureText: { fontSize: '14px', color: '#475569', lineHeight: '1.6', marginBottom: '24px' },
  signatureInputGroup: { marginBottom: '16px' },
  signatureLabel: { display: 'block', fontSize: '14px', fontWeight: '500', marginBottom: '8px', color: '#374151' },
  signatureInput: {
    width: '100%',
    padding: '12px 16px',
    fontSize: '16px',
    border: '2px solid #e2e8f0',
    borderRadius: '8px',
    boxSizing: 'border-box'
  },
  checkboxLabel: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '12px',
    fontSize: '14px',
    color: '#475569',
    cursor: 'pointer',
    marginTop: '20px'
  },
  checkbox: { width: '20px', height: '20px', cursor: 'pointer' },
  loadingBox: { textAlign: 'center', padding: '60px' },
  spinner: {
    width: '40px',
    height: '40px',
    border: '4px solid #e2e8f0',
    borderTopColor: '#7c3aed',
    borderRadius: '50%',
    animation: 'spin 1s linear infinite',
    margin: '0 auto 16px'
  },
  paidSuccess: {
    textAlign: 'center',
    padding: '32px',
    backgroundColor: '#f0fdf4',
    borderRadius: '16px',
    marginBottom: '24px'
  },
  paidIcon: { fontSize: '60px' },
  paidTitle: { margin: '16px 0 8px', color: '#166534' },
  paidPlan: { color: '#22c55e', fontWeight: '600', margin: '4px 0' },
  paidAmount: { fontSize: '32px', fontWeight: '800', color: '#166534' },
  cpaNote: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '16px',
    backgroundColor: '#f5f3ff',
    border: '2px solid #7c3aed',
    borderRadius: '12px',
    padding: '20px',
    marginBottom: '24px'
  },
  cpaIcon: { fontSize: '32px' },
  fileIrsBtn: {
    width: '100%',
    padding: '16px',
    fontSize: '18px',
    fontWeight: '700',
    backgroundColor: '#3b82f6',
    color: 'white',
    border: 'none',
    borderRadius: '12px',
    cursor: 'pointer'
  },
  paymentSubtitle: { color: '#64748b', marginBottom: '24px' },
  plansGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' },
  planCard: { borderRadius: '12px', padding: '20px', cursor: 'pointer', transition: 'all 0.2s', position: 'relative' },
  planHeader: { display: 'flex', alignItems: 'flex-start', gap: '12px', marginBottom: '12px' },
  planIcon: { fontSize: '28px' },
  planName: { margin: 0, fontSize: '16px', fontWeight: '600' },
  planDesc: { margin: '4px 0 0', fontSize: '12px', color: '#64748b' },
  radio: { marginLeft: 'auto' },
  planPrice: { fontSize: '28px', fontWeight: '800', marginBottom: '12px', color: '#1e293b' },
  planFeatures: { listStyle: 'none', padding: 0, margin: 0, fontSize: '13px', color: '#475569' },
  recommendedBadge: {
    position: 'absolute',
    top: '-10px',
    right: '16px',
    backgroundColor: '#7c3aed',
    color: 'white',
    padding: '4px 12px',
    borderRadius: '12px',
    fontSize: '10px',
    fontWeight: '700'
  },
  totalBox: { backgroundColor: '#1e293b', color: 'white', borderRadius: '12px', padding: '16px 20px' },
  totalRow: { display: 'flex', justifyContent: 'space-between', marginBottom: '8px', fontSize: '14px', color: '#94a3b8' },
  totalFinal: { display: 'flex', justifyContent: 'space-between', fontSize: '18px', fontWeight: '600' },
  totalAmount: { color: '#22c55e', fontSize: '24px', fontWeight: '800' },
  completeBox: { textAlign: 'center', padding: '40px 20px' },
  completeIcon: { fontSize: '80px' },
  completeTitle: { fontSize: '28px', margin: '16px 0', color: '#166534' },
  completeText: { color: '#64748b', fontSize: '16px', lineHeight: '1.6', marginBottom: '24px' },
  confirmationBox: { backgroundColor: '#f8fafc', borderRadius: '12px', padding: '20px', marginBottom: '24px' },
  doneBtn: {
    padding: '14px 48px',
    fontSize: '16px',
    fontWeight: '600',
    backgroundColor: '#22c55e',
    color: 'white',
    border: 'none',
    borderRadius: '12px',
    cursor: 'pointer'
  },
  footer: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '20px 32px',
    borderTop: '1px solid #e2e8f0',
    backgroundColor: '#f8fafc'
  },
  backBtn: {
    padding: '12px 24px',
    fontSize: '16px',
    fontWeight: '500',
    backgroundColor: 'white',
    color: '#64748b',
    border: '2px solid #e2e8f0',
    borderRadius: '10px',
    cursor: 'pointer'
  },
  nextBtn: {
    padding: '12px 32px',
    fontSize: '16px',
    fontWeight: '600',
    backgroundColor: '#7c3aed',
    color: 'white',
    border: 'none',
    borderRadius: '10px',
    cursor: 'pointer'
  },
  payBtn: {
    padding: '12px 32px',
    fontSize: '16px',
    fontWeight: '600',
    backgroundColor: '#22c55e',
    color: 'white',
    border: 'none',
    borderRadius: '10px',
    cursor: 'pointer'
  }
};
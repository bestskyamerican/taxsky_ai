// ============================================================
// STATS CARDS - Dashboard Statistics
// ============================================================
// Location: frontend/src/components/cpa/StatsCards.jsx
// ============================================================

import React from 'react';

export default function StatsCards({ stats, loading }) {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-white rounded-lg shadow p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          </div>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: 'Pending Review',
      value: stats?.pending || 0,
      icon: '⏳',
      color: 'bg-yellow-500',
      textColor: 'text-yellow-600',
      bgLight: 'bg-yellow-50'
    },
    {
      title: 'Approved',
      value: stats?.approved || 0,
      icon: '✅',
      color: 'bg-green-500',
      textColor: 'text-green-600',
      bgLight: 'bg-green-50'
    },
    {
      title: 'Rejected',
      value: stats?.rejected || 0,
      icon: '❌',
      color: 'bg-red-500',
      textColor: 'text-red-600',
      bgLight: 'bg-red-50'
    },
    {
      title: 'Total Files',
      value: stats?.total || 0,
      icon: '📁',
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
      bgLight: 'bg-blue-50'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      {cards.map((card, index) => (
        <div
          key={index}
          className={`${card.bgLight} rounded-lg shadow p-6 border-l-4 ${card.color.replace('bg-', 'border-')}`}
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-gray-500 text-sm font-medium">{card.title}</p>
              <p className={`text-3xl font-bold ${card.textColor} mt-1`}>
                {card.value.toLocaleString()}
              </p>
            </div>
            <span className="text-3xl">{card.icon}</span>
          </div>
          
          {/* Today's stat if available */}
          {card.title === 'Pending Review' && stats?.today && (
            <p className="text-xs text-gray-500 mt-2">
              +{stats.today.uploaded} today
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

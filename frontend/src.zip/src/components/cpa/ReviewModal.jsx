// ============================================================
// REVIEW MODAL - Complete Tax Return View
// ============================================================
// Shows: Multiple W-2s, 1099s, Spouse info, Dependents
// Location: frontend/src/components/cpa/ReviewModal.jsx
// ============================================================

import React, { useState, useEffect } from 'react';

export default function ReviewModal({ file, onClose, onSubmit }) {
  const [status, setStatus] = useState('approved');
  const [comments, setComments] = useState('');
  const [corrections, setCorrections] = useState({});
  const [showCorrections, setShowCorrections] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('document');
  
  const [userFilings, setUserFilings] = useState(null);
  const [loadingUserData, setLoadingUserData] = useState(false);
  const [error, setError] = useState(null);

  const data = file?.extractedData || {};
  const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

  // Get the file URL
  const getFileUrl = () => {
    if (!file) return null;
    if (file.filePath?.startsWith('http')) return file.filePath;
    if (file.fileName) return `${API_URL}/uploads/unknown/${file.fileName}`;
    if (file.filePath) return `${API_URL}${file.filePath.startsWith('/') ? '' : '/'}${file.filePath}`;
    return null;
  };

  const fileUrl = getFileUrl();

  useEffect(() => {
    // Load user data immediately for summary
    if (file?.userId && !userFilings) {
      loadUserData();
    }
  }, [file?.userId]);

  async function loadUserData() {
    try {
      setLoadingUserData(true);
      setError(null);
      const token = localStorage.getItem('cpa_token');
      const res = await fetch(`${API_URL}/api/cpa/users/${file.userId}/filings`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      if (data.success) {
        setUserFilings(data);
      } else {
        setError(data.error || 'Failed to load');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoadingUserData(false);
    }
  }

  const editableFields = [
    { key: 'wages_tips_other_comp', label: 'Wages (Box 1)' },
    { key: 'federal_income_tax_withheld', label: 'Federal Withheld (Box 2)' },
    { key: 'social_security_wages', label: 'SS Wages (Box 3)' },
    { key: 'social_security_tax_withheld', label: 'SS Tax (Box 4)' },
    { key: 'medicare_wages_tips', label: 'Medicare Wages (Box 5)' },
    { key: 'medicare_tax_withheld', label: 'Medicare Tax (Box 6)' },
    { key: 'state_wages', label: 'State Wages (Box 16)' },
    { key: 'state_income_tax', label: 'State Tax (Box 17)' },
  ];

  function handleCorrection(key, value) {
    setCorrections({ ...corrections, [key]: value });
  }

  async function handleSubmit() {
    setLoading(true);
    await onSubmit(file._id, {
      status,
      comments,
      corrections: showCorrections && Object.keys(corrections).length > 0 ? corrections : undefined
    });
    setLoading(false);
  }

  function formatValue(value) {
    if (value === undefined || value === null || value === '') return 'N/A';
    if (typeof value === 'number') return '$' + value.toLocaleString();
    return String(value);
  }

  function formatDate(dateStr) {
    if (!dateStr) return '';
    try { return new Date(dateStr).toLocaleString(); } 
    catch (e) { return dateStr; }
  }

  // Extract data from userFilings
  const chatHistory = userFilings?.chatHistory || userFilings?.userData?.conversation_history || [];
  const allUserFiles = userFilings?.uploadedFiles || [];
  const userAnswers = userFilings?.userData || {};
  const sessionForms = userFilings?.sessionForms || {};
  
  // Get all W-2s and 1099s from session
  const allW2s = sessionForms['W-2'] || [];
  const all1099NECs = sessionForms['1099-NEC'] || [];
  const all1099INTs = sessionForms['1099-INT'] || [];
  const all1099DIVs = sessionForms['1099-DIV'] || [];

  // Calculate totals
  const totalW2Wages = allW2s.reduce((sum, w2) => sum + (parseFloat(w2.wages_tips_other_comp) || 0), 0);
  const totalW2FedWithheld = allW2s.reduce((sum, w2) => sum + (parseFloat(w2.federal_income_tax_withheld) || 0), 0);
  const totalW2StateWithheld = allW2s.reduce((sum, w2) => sum + (parseFloat(w2.state_income_tax) || 0), 0);
  const total1099Income = all1099NECs.reduce((sum, nec) => sum + (parseFloat(nec.nonemployee_compensation) || 0), 0);

  // Check if has spouse
  const hasSpouse = userAnswers.filing_status === 'married_filing_jointly' || 
                    userAnswers.filing_status === 'married_filing_separately' ||
                    userAnswers.spouse_first_name;

  // Get dependents
  const dependentCount = parseInt(userAnswers.dependent_count) || 0;
  const dependents = userAnswers.dependents || [];

  if (!file) return null;

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      backgroundColor: 'rgba(0,0,0,0.6)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
      padding: '16px'
    }}>
      <div style={{
        backgroundColor: 'white',
        borderRadius: '16px',
        width: '100%',
        maxWidth: '1400px',
        maxHeight: '95vh',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '0 25px 50px rgba(0,0,0,0.3)'
      }}>
        {/* Header */}
        <div style={{
          background: 'linear-gradient(135deg, #1e40af 0%, #7c3aed 100%)',
          color: 'white',
          padding: '16px 24px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 'bold' }}>
              📋 Review Document
            </h2>
            <p style={{ margin: '4px 0 0', opacity: 0.9, fontSize: '13px' }}>
              {file.formType || 'W-2'} • {data.employee_name || 'Unknown'} • User: {file.userId}
            </p>
          </div>
          <button onClick={onClose} style={{
            background: 'rgba(255,255,255,0.2)',
            border: 'none',
            color: 'white',
            fontSize: '18px',
            cursor: 'pointer',
            width: '32px',
            height: '32px',
            borderRadius: '50%'
          }}>✕</button>
        </div>

        {/* Tabs */}
        <div style={{
          display: 'flex',
          borderBottom: '2px solid #e5e7eb',
          backgroundColor: '#f8fafc',
          overflowX: 'auto'
        }}>
          {[
            { id: 'document', label: 'Document', icon: '📄' },
            { id: 'taxReturn', label: 'Tax Return', icon: '📊', badge: allW2s.length + all1099NECs.length },
            { id: 'family', label: 'Family', icon: '👨‍👩‍👧‍👦', badge: hasSpouse ? dependentCount + 1 : dependentCount },
            { id: 'chat', label: 'Chat', icon: '💬', badge: chatHistory.length },
            { id: 'allDocs', label: 'Files', icon: '📁', badge: allUserFiles.length },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                padding: '12px 18px',
                border: 'none',
                borderBottom: activeTab === tab.id ? '3px solid #2563eb' : '3px solid transparent',
                backgroundColor: activeTab === tab.id ? 'white' : 'transparent',
                color: activeTab === tab.id ? '#2563eb' : '#64748b',
                fontWeight: '600',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                fontSize: '13px',
                whiteSpace: 'nowrap'
              }}
            >
              <span>{tab.icon}</span>
              {tab.label}
              {tab.badge > 0 && (
                <span style={{
                  backgroundColor: activeTab === tab.id ? '#2563eb' : '#94a3b8',
                  color: 'white',
                  padding: '2px 6px',
                  borderRadius: '10px',
                  fontSize: '11px'
                }}>{tab.badge}</span>
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflow: 'auto', padding: '20px' }}>
          
          {/* Document Tab */}
          {activeTab === 'document' && (
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
              {/* Left: Original Image */}
              <div style={{ backgroundColor: '#1e293b', borderRadius: '12px', padding: '16px' }}>
                <h4 style={{ color: 'white', margin: '0 0 12px', fontSize: '14px' }}>🖼️ Original Document</h4>
                {fileUrl ? (
                  <div style={{ backgroundColor: '#0f172a', borderRadius: '8px', padding: '8px', maxHeight: '500px', overflow: 'auto' }}>
                    <img src={fileUrl} alt="Document" style={{ width: '100%', borderRadius: '4px' }} />
                  </div>
                ) : (
                  <div style={{ backgroundColor: '#0f172a', borderRadius: '8px', padding: '60px', textAlign: 'center', color: '#64748b' }}>
                    <div style={{ fontSize: '48px' }}>📄</div>
                    <p>No file available</p>
                  </div>
                )}
              </div>

              {/* Right: Data + Review */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {/* Extracted Data */}
                <div style={{ backgroundColor: '#f1f5f9', borderRadius: '12px', padding: '16px' }}>
                  <h4 style={{ margin: '0 0 12px', fontSize: '14px', color: '#475569' }}>📊 Extracted Data</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '13px' }}>
                    <div>
                      <p style={{ margin: '4px 0' }}><strong>Employee:</strong> {data.employee_name || 'N/A'}</p>
                      <p style={{ margin: '4px 0' }}><strong>SSN:</strong> ***-**-{String(data.employee_ssn || '').slice(-4) || 'N/A'}</p>
                      <p style={{ margin: '4px 0' }}><strong>Employer:</strong> {data.employer_name || 'N/A'}</p>
                      <p style={{ margin: '4px 0' }}><strong>EIN:</strong> {data.employer_ein || 'N/A'}</p>
                    </div>
                    <div>
                      <p style={{ margin: '4px 0' }}><strong>Wages:</strong> {formatValue(data.wages_tips_other_comp)}</p>
                      <p style={{ margin: '4px 0' }}><strong>Fed Tax:</strong> {formatValue(data.federal_income_tax_withheld)}</p>
                      <p style={{ margin: '4px 0' }}><strong>SS Tax:</strong> {formatValue(data.social_security_tax_withheld)}</p>
                      <p style={{ margin: '4px 0' }}><strong>State Tax:</strong> {formatValue(data.state_income_tax)}</p>
                    </div>
                  </div>
                </div>

                {/* Review Actions */}
                <div style={{ backgroundColor: 'white', border: '2px solid #e2e8f0', borderRadius: '12px', padding: '16px' }}>
                  <h4 style={{ margin: '0 0 12px', fontSize: '14px' }}>✅ Your Review</h4>
                  
                  <div style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
                    <button onClick={() => setStatus('approved')} style={{
                      flex: 1, padding: '12px',
                      border: status === 'approved' ? '2px solid #22c55e' : '2px solid #e2e8f0',
                      borderRadius: '8px',
                      backgroundColor: status === 'approved' ? '#f0fdf4' : 'white',
                      cursor: 'pointer', fontWeight: '600',
                      color: status === 'approved' ? '#16a34a' : '#64748b'
                    }}>✓ Approve</button>
                    <button onClick={() => setStatus('rejected')} style={{
                      flex: 1, padding: '12px',
                      border: status === 'rejected' ? '2px solid #ef4444' : '2px solid #e2e8f0',
                      borderRadius: '8px',
                      backgroundColor: status === 'rejected' ? '#fef2f2' : 'white',
                      cursor: 'pointer', fontWeight: '600',
                      color: status === 'rejected' ? '#dc2626' : '#64748b'
                    }}>✗ Reject</button>
                  </div>

                  <textarea
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    placeholder="Comments..."
                    style={{ width: '100%', padding: '10px', border: '1px solid #e2e8f0', borderRadius: '8px', minHeight: '60px', resize: 'vertical', boxSizing: 'border-box' }}
                  />

                  <label style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '10px', cursor: 'pointer', fontSize: '13px' }}>
                    <input type="checkbox" checked={showCorrections} onChange={(e) => setShowCorrections(e.target.checked)} />
                    Make corrections
                  </label>

                  {showCorrections && (
                    <div style={{ marginTop: '10px', backgroundColor: '#fefce8', padding: '12px', borderRadius: '8px', fontSize: '12px' }}>
                      {editableFields.map(f => (
                        <div key={f.key} style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                          <label style={{ width: '140px', color: '#713f12' }}>{f.label}:</label>
                          <input
                            type="number"
                            step="0.01"
                            defaultValue={data[f.key] || ''}
                            onChange={(e) => handleCorrection(f.key, parseFloat(e.target.value))}
                            style={{ flex: 1, padding: '4px 8px', border: '1px solid #fde047', borderRadius: '4px' }}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tax Return Summary Tab */}
          {activeTab === 'taxReturn' && (
            <div>
              <h3 style={{ marginTop: 0, marginBottom: '16px' }}>📊 Complete Tax Return Summary</h3>
              
              {loadingUserData ? (
                <p>Loading tax data...</p>
              ) : (
                <div style={{ display: 'grid', gap: '20px' }}>
                  {/* Totals Summary */}
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(4, 1fr)', 
                    gap: '12px' 
                  }}>
                    <div style={{ backgroundColor: '#eff6ff', padding: '16px', borderRadius: '10px', textAlign: 'center' }}>
                      <div style={{ fontSize: '24px', fontWeight: '700', color: '#1e40af' }}>{formatValue(totalW2Wages)}</div>
                      <div style={{ fontSize: '12px', color: '#3b82f6' }}>Total W-2 Wages</div>
                    </div>
                    <div style={{ backgroundColor: '#f0fdf4', padding: '16px', borderRadius: '10px', textAlign: 'center' }}>
                      <div style={{ fontSize: '24px', fontWeight: '700', color: '#166534' }}>{formatValue(total1099Income)}</div>
                      <div style={{ fontSize: '12px', color: '#22c55e' }}>1099 Income</div>
                    </div>
                    <div style={{ backgroundColor: '#fef3c7', padding: '16px', borderRadius: '10px', textAlign: 'center' }}>
                      <div style={{ fontSize: '24px', fontWeight: '700', color: '#92400e' }}>{formatValue(totalW2FedWithheld)}</div>
                      <div style={{ fontSize: '12px', color: '#d97706' }}>Fed Withheld</div>
                    </div>
                    <div style={{ backgroundColor: '#fce7f3', padding: '16px', borderRadius: '10px', textAlign: 'center' }}>
                      <div style={{ fontSize: '24px', fontWeight: '700', color: '#9d174d' }}>{formatValue(totalW2StateWithheld)}</div>
                      <div style={{ fontSize: '12px', color: '#ec4899' }}>State Withheld</div>
                    </div>
                  </div>

                  {/* All W-2s */}
                  <div style={{ backgroundColor: '#f8fafc', borderRadius: '12px', padding: '16px' }}>
                    <h4 style={{ margin: '0 0 12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ backgroundColor: '#dbeafe', color: '#1e40af', padding: '4px 10px', borderRadius: '6px', fontSize: '12px' }}>W-2</span>
                      All W-2 Forms ({allW2s.length})
                    </h4>
                    
                    {allW2s.length === 0 ? (
                      <p style={{ color: '#64748b' }}>No W-2 forms found</p>
                    ) : (
                      <div style={{ display: 'grid', gap: '10px' }}>
                        {allW2s.map((w2, idx) => (
                          <div key={idx} style={{
                            backgroundColor: 'white',
                            border: '1px solid #e2e8f0',
                            borderRadius: '8px',
                            padding: '12px',
                            display: 'grid',
                            gridTemplateColumns: '2fr 1fr 1fr 1fr',
                            gap: '12px',
                            alignItems: 'center'
                          }}>
                            <div>
                              <div style={{ fontWeight: '600' }}>{w2.employer_name || 'Unknown Employer'}</div>
                              <div style={{ fontSize: '12px', color: '#64748b' }}>EIN: {w2.employer_ein || 'N/A'}</div>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                              <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>{formatValue(w2.wages_tips_other_comp)}</div>
                              <div style={{ fontSize: '11px', color: '#64748b' }}>Wages</div>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                              <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>{formatValue(w2.federal_income_tax_withheld)}</div>
                              <div style={{ fontSize: '11px', color: '#64748b' }}>Fed Tax</div>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                              <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>{formatValue(w2.state_income_tax)}</div>
                              <div style={{ fontSize: '11px', color: '#64748b' }}>State Tax</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* All 1099-NECs */}
                  {all1099NECs.length > 0 && (
                    <div style={{ backgroundColor: '#f0fdf4', borderRadius: '12px', padding: '16px' }}>
                      <h4 style={{ margin: '0 0 12px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{ backgroundColor: '#dcfce7', color: '#166534', padding: '4px 10px', borderRadius: '6px', fontSize: '12px' }}>1099-NEC</span>
                        Self-Employment Income ({all1099NECs.length})
                      </h4>
                      <div style={{ display: 'grid', gap: '10px' }}>
                        {all1099NECs.map((nec, idx) => (
                          <div key={idx} style={{
                            backgroundColor: 'white',
                            border: '1px solid #bbf7d0',
                            borderRadius: '8px',
                            padding: '12px',
                            display: 'flex',
                            justifyContent: 'space-between'
                          }}>
                            <div>
                              <div style={{ fontWeight: '600' }}>{nec.payer_name || 'Unknown Payer'}</div>
                              <div style={{ fontSize: '12px', color: '#64748b' }}>EIN: {nec.payer_ein || 'N/A'}</div>
                            </div>
                            <div style={{ textAlign: 'right' }}>
                              <div style={{ fontWeight: '700', fontFamily: 'monospace', fontSize: '18px' }}>{formatValue(nec.nonemployee_compensation)}</div>
                              <div style={{ fontSize: '11px', color: '#64748b' }}>Non-employee Comp</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Filing Info */}
                  <div style={{ backgroundColor: '#f1f5f9', borderRadius: '12px', padding: '16px' }}>
                    <h4 style={{ margin: '0 0 12px' }}>📝 Filing Information</h4>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px', fontSize: '14px' }}>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>Filing Status</div>
                        <div style={{ fontWeight: '600', textTransform: 'capitalize' }}>{userAnswers.filing_status?.replace(/_/g, ' ') || 'N/A'}</div>
                      </div>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>State</div>
                        <div style={{ fontWeight: '600' }}>{userAnswers.state || 'N/A'}</div>
                      </div>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>Dependents</div>
                        <div style={{ fontWeight: '600' }}>{dependentCount}</div>
                      </div>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>Language</div>
                        <div style={{ fontWeight: '600' }}>{(userAnswers.preferred_language || 'EN').toUpperCase()}</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Family Tab */}
          {activeTab === 'family' && (
            <div>
              <h3 style={{ marginTop: 0, marginBottom: '16px' }}>👨‍👩‍👧‍👦 Family Information</h3>
              
              {loadingUserData ? (
                <p>Loading...</p>
              ) : (
                <div style={{ display: 'grid', gap: '20px' }}>
                  {/* Taxpayer */}
                  <div style={{ backgroundColor: '#eff6ff', borderRadius: '12px', padding: '20px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                      <div style={{ width: '48px', height: '48px', backgroundColor: '#2563eb', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '20px' }}>
                        👤
                      </div>
                      <div>
                        <div style={{ fontWeight: '700', fontSize: '18px' }}>{userAnswers.first_name} {userAnswers.last_name}</div>
                        <div style={{ color: '#3b82f6', fontSize: '13px' }}>Primary Taxpayer</div>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', fontSize: '14px' }}>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>SSN</div>
                        <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>***-**-{String(userAnswers.ssn || '').slice(-4) || 'N/A'}</div>
                      </div>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>Date of Birth</div>
                        <div style={{ fontWeight: '600' }}>{userAnswers.dob || 'N/A'}</div>
                      </div>
                      <div>
                        <div style={{ color: '#64748b', fontSize: '12px' }}>Address</div>
                        <div style={{ fontWeight: '600' }}>{userAnswers.address || 'N/A'}</div>
                      </div>
                    </div>
                  </div>

                  {/* Spouse */}
                  {hasSpouse && (
                    <div style={{ backgroundColor: '#fdf4ff', borderRadius: '12px', padding: '20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                        <div style={{ width: '48px', height: '48px', backgroundColor: '#a855f7', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '20px' }}>
                          💑
                        </div>
                        <div>
                          <div style={{ fontWeight: '700', fontSize: '18px' }}>{userAnswers.spouse_first_name} {userAnswers.spouse_last_name}</div>
                          <div style={{ color: '#a855f7', fontSize: '13px' }}>Spouse</div>
                        </div>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', fontSize: '14px' }}>
                        <div>
                          <div style={{ color: '#64748b', fontSize: '12px' }}>SSN</div>
                          <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>***-**-{String(userAnswers.spouse_ssn || '').slice(-4) || 'N/A'}</div>
                        </div>
                        <div>
                          <div style={{ color: '#64748b', fontSize: '12px' }}>Date of Birth</div>
                          <div style={{ fontWeight: '600' }}>{userAnswers.spouse_dob || 'N/A'}</div>
                        </div>
                        <div>
                          <div style={{ color: '#64748b', fontSize: '12px' }}>Occupation</div>
                          <div style={{ fontWeight: '600' }}>{userAnswers.spouse_occupation || 'N/A'}</div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Dependents */}
                  <div style={{ backgroundColor: '#f0fdf4', borderRadius: '12px', padding: '20px' }}>
                    <h4 style={{ margin: '0 0 16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      👶 Dependents ({dependentCount})
                    </h4>
                    
                    {dependentCount === 0 ? (
                      <p style={{ color: '#64748b', margin: 0 }}>No dependents claimed</p>
                    ) : dependents.length > 0 ? (
                      <div style={{ display: 'grid', gap: '12px' }}>
                        {dependents.map((dep, idx) => (
                          <div key={idx} style={{
                            backgroundColor: 'white',
                            border: '1px solid #bbf7d0',
                            borderRadius: '8px',
                            padding: '12px',
                            display: 'grid',
                            gridTemplateColumns: 'auto 1fr 1fr 1fr',
                            gap: '12px',
                            alignItems: 'center'
                          }}>
                            <div style={{ width: '36px', height: '36px', backgroundColor: '#22c55e', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
                              {idx + 1}
                            </div>
                            <div>
                              <div style={{ fontWeight: '600' }}>{dep.first_name} {dep.last_name}</div>
                              <div style={{ fontSize: '12px', color: '#64748b' }}>Dependent</div>
                            </div>
                            <div>
                              <div style={{ fontSize: '12px', color: '#64748b' }}>SSN</div>
                              <div style={{ fontFamily: 'monospace' }}>***-**-{String(dep.ssn || '').slice(-4) || 'N/A'}</div>
                            </div>
                            <div>
                              <div style={{ fontSize: '12px', color: '#64748b' }}>Relationship</div>
                              <div>{dep.relationship || 'Child'}</div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p style={{ color: '#64748b', margin: 0 }}>{dependentCount} dependent(s) claimed (details not available)</p>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Chat Tab */}
          {activeTab === 'chat' && (
            <div>
              <h3 style={{ marginTop: 0 }}>💬 Conversation History</h3>
              {loadingUserData ? (
                <p>Loading...</p>
              ) : chatHistory.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', backgroundColor: '#f8fafc', borderRadius: '12px' }}>
                  <div style={{ fontSize: '48px' }}>💬</div>
                  <p style={{ color: '#64748b' }}>No chat history</p>
                </div>
              ) : (
                <div style={{ maxHeight: '450px', overflow: 'auto' }}>
                  {chatHistory.map((msg, i) => (
                    <div key={i} style={{
                      padding: '12px 16px',
                      marginBottom: '8px',
                      borderRadius: '10px',
                      backgroundColor: msg.role === 'user' ? '#dbeafe' : '#f1f5f9',
                      marginLeft: msg.role === 'user' ? '40px' : '0',
                      marginRight: msg.role === 'user' ? '0' : '40px'
                    }}>
                      <div style={{ fontWeight: '600', fontSize: '12px', color: '#64748b', marginBottom: '4px' }}>
                        {msg.role === 'user' ? '👤 User' : '🤖 AI'}
                        {msg.timestamp && <span style={{ marginLeft: '8px', fontWeight: '400' }}>{formatDate(msg.timestamp)}</span>}
                      </div>
                      <div style={{ whiteSpace: 'pre-wrap', fontSize: '14px' }}>{msg.content}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* All Files Tab */}
          {activeTab === 'allDocs' && (
            <div>
              <h3 style={{ marginTop: 0 }}>📁 All Uploaded Files</h3>
              {loadingUserData ? (
                <p>Loading...</p>
              ) : allUserFiles.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '60px', backgroundColor: '#f8fafc', borderRadius: '12px' }}>
                  <p style={{ color: '#64748b' }}>No files uploaded</p>
                </div>
              ) : (
                <div style={{ display: 'grid', gap: '10px' }}>
                  {allUserFiles.map((doc, i) => (
                    <div key={i} style={{
                      padding: '12px 16px',
                      borderRadius: '10px',
                      border: doc._id === file._id ? '2px solid #2563eb' : '1px solid #e2e8f0',
                      backgroundColor: doc._id === file._id ? '#eff6ff' : 'white',
                      display: 'flex',
                      justifyContent: 'space-between'
                    }}>
                      <div>
                        <span style={{ backgroundColor: '#dbeafe', color: '#1e40af', padding: '2px 8px', borderRadius: '4px', fontSize: '12px' }}>{doc.formType}</span>
                        {doc._id === file._id && <span style={{ marginLeft: '8px', color: '#2563eb', fontSize: '11px' }}>← Current</span>}
                        <p style={{ margin: '6px 0 0', fontWeight: '500' }}>{doc.extractedData?.employee_name || doc.extractedData?.employer_name || 'Unknown'}</p>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <p style={{ margin: 0, fontFamily: 'monospace', fontWeight: '600' }}>{formatValue(doc.extractedData?.wages_tips_other_comp || doc.extractedData?.nonemployee_compensation)}</p>
                        <span style={{
                          backgroundColor: doc.status === 'approved' ? '#dcfce7' : doc.status === 'rejected' ? '#fee2e2' : '#fef9c3',
                          color: doc.status === 'approved' ? '#166534' : doc.status === 'rejected' ? '#991b1b' : '#854d0e',
                          padding: '2px 8px',
                          borderRadius: '4px',
                          fontSize: '11px'
                        }}>{doc.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          padding: '14px 24px',
          borderTop: '2px solid #e5e7eb',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          backgroundColor: '#f8fafc'
        }}>
          <span style={{ fontSize: '12px', color: '#94a3b8' }}>
            ID: {file._id?.slice(-8)} | {file.fileName || 'N/A'}
          </span>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button onClick={onClose} disabled={loading} style={{
              padding: '10px 24px',
              border: '2px solid #e2e8f0',
              borderRadius: '8px',
              backgroundColor: 'white',
              cursor: 'pointer',
              fontWeight: '600'
            }}>Cancel</button>
            <button onClick={handleSubmit} disabled={loading || (status === 'rejected' && !comments)} style={{
              padding: '10px 24px',
              border: 'none',
              borderRadius: '8px',
              backgroundColor: status === 'approved' ? '#22c55e' : '#ef4444',
              color: 'white',
              fontWeight: '600',
              cursor: loading ? 'not-allowed' : 'pointer',
              opacity: loading ? 0.5 : 1
            }}>
              {loading ? '...' : (status === 'approved' ? '✓ Approve' : '✗ Reject')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
// ============================================================
// TAXSKY APP WITH GOOGLE LOGIN (LANGUAGE LOCKED AT LOGIN)
// ============================================================

import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { createContext, useContext, useState, useEffect } from "react";
import Onboarding from "./pages/Onboarding";
import TaxChatPage from "./pages/TaxChatPage";

// ============================================================
// CONFIGURATION
// ============================================================

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

// ============================================================
// AUTH CONTEXT
// ============================================================

const AuthContext = createContext(null);

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

// ============================================================
// AUTH PROVIDER
// ============================================================

function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedToken = localStorage.getItem("taxsky_token");
    const savedUser = localStorage.getItem("taxsky_user");

    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
      verifyToken(savedToken);
    } else {
      setLoading(false);
    }
  }, []);

  const verifyToken = async (authToken) => {
    try {
      const res = await fetch(`${API_URL}/api/auth/verify`, {
        headers: { Authorization: `Bearer ${authToken}` }
      });
      if (!res.ok) logout();
    } catch (err) {
      console.error("Token verification failed:", err);
    } finally {
      setLoading(false);
    }
  };

  const login = (userData, authToken) => {
    setUser(userData);
    setToken(authToken);
    localStorage.setItem("taxsky_token", authToken);
    localStorage.setItem("taxsky_user", JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("taxsky_token");
    localStorage.removeItem("taxsky_user");
  };

  return (
    <AuthContext.Provider
      value={{ user, token, loading, isAuthenticated: !!user, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ============================================================
// GOOGLE LOGIN PAGE (LANGUAGE SELECTED HERE)
// ============================================================

function LoginPage() {
  const { login } = useAuth();
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState("en"); // 🔒 LOCKED AFTER LOGIN

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);

    script.onload = () => {
      if (window.google && GOOGLE_CLIENT_ID) {
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleGoogleResponse,
        });

        window.google.accounts.id.renderButton(
          document.getElementById("google-signin-button"),
          {
            theme: "outline",
            size: "large",
            text: "signin_with",
            shape: "rectangular",
            width: 300,
          }
        );
      }
    };

    return () => {
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, [language]);

  const handleGoogleResponse = async (response) => {
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch(`${API_URL}/api/auth/google`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          credential: response.credential,
          language, // ✅ SEND LANGUAGE
        }),
      });

      const data = await res.json();

      if (data.success) {
        login(data.user, data.token);
      } else {
        throw new Error(data.error || "Login failed");
      }
    } catch (err) {
      console.error("Login error:", err);
      setError(err.message || "Login failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={styles.loginPage}>
      <div style={styles.loginContainer}>
        <div style={styles.loginHeader}>
          <div style={styles.logo}>🌤️</div>
          <h1 style={styles.title}>TaxSky AI</h1>
          <p style={styles.subtitle}>Smart Tax Filing Made Easy</p>
        </div>

        <div style={styles.loginCard}>
          <h2 style={styles.cardTitle}>Welcome!</h2>
          <p style={styles.cardText}>Sign in with Google to file your taxes</p>

          {/* LANGUAGE SELECTOR */}
          <div style={{ marginBottom: "20px" }}>
            <label style={{ fontSize: "0.9rem", color: "#555" }}>
              🌐 Language
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              style={{
                width: "100%",
                marginTop: "6px",
                padding: "10px",
                borderRadius: "8px",
                border: "1px solid #ddd",
                fontSize: "0.95rem",
              }}
            >
              <option value="en">English</option>
              <option value="vi">Tiếng Việt</option>
              <option value="es">Español</option>
            </select>
          </div>

          {error && <div style={styles.errorBox}>{error}</div>}

          <div style={styles.buttonContainer}>
            {isLoading ? (
              <div style={styles.loading}>Signing in...</div>
            ) : (
              <div id="google-signin-button"></div>
            )}
          </div>
        </div>

        <p style={styles.footer}>
          By signing in, you agree to our Terms of Service and Privacy Policy
        </p>
      </div>
    </div>
  );
}

// ============================================================
// PROTECTED ROUTE
// ============================================================

function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div style={styles.loadingScreen}>
        <div style={styles.spinner}></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return children;
}

// ============================================================
// USER PREF CHECK (NO LOCALSTORAGE)
// ============================================================

function hasUserPreferences(user) {
  return !!user?.language && !!user?.state;
}

// ============================================================
// MAIN APP
// ============================================================

export default function App() {
  const { user } = useAuth() || {};

  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedRoute>
                {hasUserPreferences(user) ? (
                  <Navigate to="/taxchat" replace />
                ) : (
                  <Onboarding />
                )}
              </ProtectedRoute>
            }
          />

          <Route
            path="/taxchat"
            element={
              <ProtectedRoute>
                {hasUserPreferences(user) ? (
                  <TaxChatPage />
                ) : (
                  <Navigate to="/" replace />
                )}
              </ProtectedRoute>
            }
          />

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

// ============================================================
// STYLES (UNCHANGED)
// ============================================================

const styles = { /* your existing styles exactly as-is */ };

// ============================================================
// i18n-complete.js - MASTER TRANSLATIONS FOR ALL TAXSKY PAGES
// ============================================================
// Supports: English (en), Vietnamese (vi), Spanish (es)
// Pages: Chat, Dashboard, File Return, Payment, Check Refund, Profile
// ============================================================

export const SUPPORTED_LANGUAGES = ['en', 'vi', 'es'];

export const translations = {
  // ============================================================
  // ENGLISH
  // ============================================================
  en: {
    // ==================== COMMON / SHARED ====================
    common: {
      appName: "TaxSky",
      tagline: "AI-Powered Tax Filing",
      taxYear: "Tax Year",
      loading: "Loading...",
      save: "Save",
      cancel: "Cancel",
      close: "Close",
      back: "Back",
      next: "Next",
      continue: "Continue",
      submit: "Submit",
      confirm: "Confirm",
      edit: "Edit",
      delete: "Delete",
      download: "Download",
      upload: "Upload",
      print: "Print",
      refresh: "Refresh",
      search: "Search",
      yes: "Yes",
      no: "No",
      ok: "OK",
      done: "Done",
      or: "or",
      and: "and",
      none: "None",
      notProvided: "Not provided",
      notSelected: "Not selected",
      required: "Required",
      optional: "Optional",
      success: "Success",
      error: "Error",
      warning: "Warning",
      info: "Info"
    },

    // ==================== NAVIGATION ====================
    nav: {
      home: "Home",
      dashboard: "Dashboard",
      chat: "Chat with AI",
      fileReturn: "File Return",
      documents: "Documents",
      payments: "Payments",
      refundStatus: "Refund Status",
      profile: "Profile",
      settings: "Settings",
      help: "Help",
      logout: "Log Out",
      login: "Log In",
      signup: "Sign Up"
    },

    // ==================== AUTH ====================
    auth: {
      login: "Log In",
      signup: "Sign Up",
      logout: "Log Out",
      email: "Email",
      password: "Password",
      confirmPassword: "Confirm Password",
      forgotPassword: "Forgot Password?",
      resetPassword: "Reset Password",
      rememberMe: "Remember me",
      noAccount: "Don't have an account?",
      hasAccount: "Already have an account?",
      loginSuccess: "Successfully logged in!",
      logoutSuccess: "Successfully logged out!",
      signupSuccess: "Account created successfully!",
      invalidCredentials: "Invalid email or password",
      passwordMismatch: "Passwords do not match",
      emailRequired: "Email is required",
      passwordRequired: "Password is required"
    },

    // ==================== SMART CHAT INTERFACE ====================
    chat: {
      title: "TaxSky AI",
      placeholder: "Ask me anything about your taxes...",
      send: "Send",
      uploading: "Uploading",
      showData: "Show Data",
      hideData: "Hide Data",
      startOver: "Start Over",
      downloadForm: "Download 1040",
      yourTaxData: "Your Tax Data",
      welcome: "👋 Hello! I'm TaxSky AI. How can I help you with your taxes today?",
      thinking: "Thinking...",
      typing: "TaxSky is typing...",
      quickActions: {
        uploadW2: "Upload W-2",
        filingStatus: "Filing Status",
        addDependent: "Add Dependent",
        checkRefund: "Check Refund",
        fileReturn: "File Return",
        askQuestion: "Ask Question"
      }
    },

    // ==================== DASHBOARD ====================
    dashboard: {
      title: "Tax Dashboard",
      welcome: "Welcome back",
      taxYear: "Tax Year {year}",
      overview: "Overview",
      quickActions: "Quick Actions",
      recentActivity: "Recent Activity",
      
      // Summary Cards
      totalIncome: "Total Income",
      totalDeductions: "Deductions",
      estimatedRefund: "Estimated Refund",
      amountOwed: "Amount Owed",
      taxesPaid: "Taxes Paid",
      
      // Status
      status: "Status",
      notStarted: "Not Started",
      inProgress: "In Progress",
      readyToFile: "Ready to File",
      filed: "Filed",
      accepted: "Accepted",
      rejected: "Rejected",
      
      // Actions
      startReturn: "Start Return",
      continueReturn: "Continue Return",
      viewReturn: "View Return",
      amendReturn: "Amend Return",
      
      // Documents
      documents: "Documents",
      uploadedDocs: "Uploaded Documents",
      w2Forms: "W-2 Forms",
      form1099: "1099 Forms",
      otherDocs: "Other Documents",
      noDocuments: "No documents uploaded yet"
    },

    // ==================== FILE TAX RETURN WIZARD ====================
    fileReturn: {
      title: "File Your Tax Return",
      
      // Steps
      steps: {
        step1: "Review Info",
        step2: "Verify Income",
        step3: "Check Refund",
        step4: "Confirm & Sign",
        step5: "Complete"
      },
      
      // Step 1: Review Info
      reviewInfo: {
        title: "Review Your Information",
        personalInfo: "Personal Information",
        name: "Name",
        ssn: "SSN",
        address: "Address",
        filingStatus: "Filing Status",
        dependents: "Dependents",
        editInfo: "Edit Information",
        addDependent: "Add Dependent",
        spouse: "Spouse Information"
      },
      
      // Step 2: Verify Income
      verifyIncome: {
        title: "Verify Your Income",
        w2Income: "W-2 Income",
        form1099Income: "1099 Income",
        otherIncome: "Other Income",
        employer: "Employer",
        wages: "Wages",
        federalWithheld: "Federal Tax Withheld",
        stateWithheld: "State Tax Withheld",
        totalIncome: "Total Income",
        noW2: "No W-2 uploaded yet",
        no1099: "No 1099 uploaded yet",
        uploadW2: "Upload W-2",
        upload1099: "Upload 1099",
        addIncome: "Add Income"
      },
      
      // Step 3: Check Refund/Summary
      checkRefund: {
        title: "Your Tax Summary",
        federal: "Federal",
        state: "State",
        taxableIncome: "Taxable Income",
        adjustedGrossIncome: "Adjusted Gross Income",
        standardDeduction: "Standard Deduction",
        itemizedDeductions: "Itemized Deductions",
        totalTax: "Total Tax",
        withheld: "Tax Withheld",
        refund: "Refund",
        owed: "Amount Owed",
        totalRefund: "Total Refund",
        totalOwed: "Total Amount Owed",
        credits: "Tax Credits Applied",
        childTaxCredit: "Child Tax Credit",
        eitc: "Earned Income Tax Credit",
        otherCredits: "Other Credits",
        effectiveRate: "Effective Tax Rate",
        marginalRate: "Marginal Tax Rate"
      },
      
      // Step 4: Confirm & Sign
      confirmSign: {
        title: "Confirm & Sign",
        reviewReturn: "Review Your Return",
        electronicSignature: "Electronic Signature",
        signatureDisclaimer: "By entering your PIN below, you are signing your tax return electronically. You confirm that all information is true, correct, and complete.",
        enterPin: "Enter 5-digit PIN",
        createPin: "Create PIN",
        confirmPin: "Confirm PIN",
        spouseSignature: "Spouse Signature",
        spousePin: "Spouse PIN (if filing jointly)",
        agreeTerms: "I agree to the terms and conditions",
        agreePerjury: "I declare under penalties of perjury that this return is true and complete",
        irsDisclosure: "Under penalties of perjury, I declare that I have examined this return and accompanying schedules and statements, and to the best of my knowledge and belief, they are true, correct, and complete.",
        practitionerPin: "Practitioner PIN (if applicable)",
        identityVerification: "Identity Verification",
        securityQuestion: "Security Question"
      },
      
      // Step 5: Complete
      complete: {
        title: "Filing Complete!",
        success: "Your tax return has been submitted successfully.",
        congratulations: "Congratulations!",
        confirmationNumber: "Confirmation Number",
        submittedOn: "Submitted On",
        expectedRefund: "Expected Refund",
        estimatedDate: "Estimated Refund Date",
        directDeposit: "Direct Deposit",
        paperCheck: "Paper Check",
        
        downloadReturn: "Download Your Return",
        download1040: "Download Form 1040",
        downloadReceipt: "Download Receipt",
        downloadAll: "Download All Documents",
        
        whatNext: "What's Next?",
        checkStatus: "Check Refund Status",
        irsAcceptance: "IRS Acceptance: Within 24-48 hours",
        refundTime: "Refund: 21 days (e-file + direct deposit)",
        trackRefund: "Track your refund at irs.gov/refunds",
        printCopy: "Print a copy for your records",
        
        stateReturn: "State Return",
        stateSubmitted: "State return also submitted",
        stateConfirmation: "State Confirmation Number"
      },
      
      // Filing Status Options
      filingStatuses: {
        single: "Single",
        married_filing_jointly: "Married Filing Jointly",
        married_filing_separately: "Married Filing Separately",
        head_of_household: "Head of Household",
        qualifying_widow: "Qualifying Surviving Spouse"
      },
      
      // Buttons
      buttons: {
        cancel: "Cancel",
        back: "Back",
        continue: "Continue",
        next: "Next",
        submit: "Submit Return",
        sign: "Sign & Submit",
        close: "Close",
        done: "Done",
        edit: "Edit",
        save: "Save",
        print: "Print",
        download: "Download",
        fileNow: "File Now",
        payNow: "Pay Now",
        reviewReturn: "Review Return"
      },
      
      // Errors & Validation
      errors: {
        required: "This field is required",
        invalidPin: "PIN must be 5 digits",
        pinMismatch: "PINs do not match",
        mustAgree: "You must agree to the terms",
        submitFailed: "Failed to submit. Please try again.",
        incompleteInfo: "Please complete all required information",
        invalidSSN: "Invalid SSN format",
        missingW2: "Please upload at least one W-2",
        missingSignature: "Signature is required"
      },
      
      // Confirmations
      confirmations: {
        cancelFiling: "Are you sure you want to cancel? Your progress will be lost.",
        submitReturn: "Are you ready to submit your tax return?",
        deleteDocument: "Are you sure you want to delete this document?"
      }
    },

    // ==================== PAYMENT ====================
    payment: {
      title: "Payment",
      payTaxes: "Pay Your Taxes",
      paymentMethod: "Payment Method",
      
      // Amount
      amountDue: "Amount Due",
      totalDue: "Total Due",
      federalTax: "Federal Tax",
      stateTax: "State Tax",
      penalties: "Penalties",
      interest: "Interest",
      serviceFee: "Service Fee",
      processingFee: "Processing Fee",
      
      // Payment Methods
      methods: {
        title: "Select Payment Method",
        creditCard: "Credit/Debit Card",
        bankAccount: "Bank Account (ACH)",
        directDebit: "Direct Debit",
        paypal: "PayPal",
        applePay: "Apple Pay",
        googlePay: "Google Pay",
        check: "Mail a Check",
        installment: "Installment Plan"
      },
      
      // Card Details
      card: {
        cardNumber: "Card Number",
        cardHolder: "Cardholder Name",
        expiryDate: "Expiration Date",
        cvv: "CVV",
        billingAddress: "Billing Address",
        saveCard: "Save card for future payments"
      },
      
      // Bank Account
      bank: {
        accountType: "Account Type",
        checking: "Checking",
        savings: "Savings",
        routingNumber: "Routing Number",
        accountNumber: "Account Number",
        confirmAccount: "Confirm Account Number",
        bankName: "Bank Name"
      },
      
      // Installment
      installment: {
        title: "Payment Plan",
        monthlyPayment: "Monthly Payment",
        numberOfPayments: "Number of Payments",
        startDate: "Start Date",
        setupFee: "Setup Fee",
        terms: "Payment Plan Terms"
      },
      
      // Status
      status: {
        pending: "Pending",
        processing: "Processing",
        completed: "Completed",
        failed: "Failed",
        refunded: "Refunded",
        cancelled: "Cancelled"
      },
      
      // Buttons
      buttons: {
        pay: "Pay",
        payNow: "Pay Now",
        submitPayment: "Submit Payment",
        schedulePayment: "Schedule Payment",
        setupPlan: "Set Up Payment Plan",
        viewHistory: "View Payment History",
        downloadReceipt: "Download Receipt"
      },
      
      // Messages
      messages: {
        success: "Payment successful!",
        failed: "Payment failed. Please try again.",
        processing: "Processing your payment...",
        confirmation: "Payment Confirmation",
        receiptSent: "Receipt sent to your email",
        thankYou: "Thank you for your payment!"
      },
      
      // Errors
      errors: {
        invalidCard: "Invalid card number",
        expiredCard: "Card has expired",
        invalidCvv: "Invalid CVV",
        invalidRouting: "Invalid routing number",
        invalidAccount: "Invalid account number",
        accountMismatch: "Account numbers do not match",
        insufficientFunds: "Insufficient funds",
        paymentDeclined: "Payment declined",
        tryAgain: "Please try again or use a different payment method"
      }
    },

    // ==================== CHECK REFUND / TAX STATUS ====================
    refundStatus: {
      title: "Refund Status",
      checkStatus: "Check Your Refund Status",
      trackRefund: "Track Your Refund",
      
      // Input
      enterInfo: "Enter your information to check status",
      ssn: "Social Security Number",
      filingStatus: "Filing Status",
      refundAmount: "Expected Refund Amount",
      
      // Status Steps
      steps: {
        received: "Return Received",
        approved: "Refund Approved",
        sent: "Refund Sent"
      },
      
      // Status Messages
      status: {
        notFiled: "Return Not Filed",
        received: "Return Received",
        processing: "Being Processed",
        approved: "Refund Approved",
        sent: "Refund Sent",
        deposited: "Refund Deposited",
        mailed: "Check Mailed",
        delayed: "Processing Delayed",
        underReview: "Under Review",
        actionRequired: "Action Required"
      },
      
      // Details
      details: {
        confirmationNumber: "Confirmation Number",
        dateFiled: "Date Filed",
        dateAccepted: "Date Accepted",
        expectedDate: "Expected Date",
        actualDate: "Actual Date",
        amount: "Refund Amount",
        method: "Delivery Method",
        directDeposit: "Direct Deposit",
        paperCheck: "Paper Check",
        bankAccount: "Bank Account ending in",
        mailingAddress: "Mailing Address"
      },
      
      // Federal & State
      federal: {
        title: "Federal Refund",
        status: "Federal Status",
        irsStatus: "IRS Status"
      },
      state: {
        title: "State Refund",
        status: "State Status"
      },
      
      // Messages
      messages: {
        checkBack: "Check back in 24-48 hours for updates",
        typical21Days: "Most refunds are issued within 21 days",
        contactIRS: "Contact the IRS if more than 21 days have passed",
        whereMyRefund: "For more details, visit irs.gov/refunds",
        noRecord: "No record found. Please verify your information.",
        stillProcessing: "Your return is still being processed"
      },
      
      // Buttons
      buttons: {
        check: "Check Status",
        refresh: "Refresh Status",
        viewDetails: "View Details",
        contactSupport: "Contact Support",
        visitIRS: "Visit IRS.gov"
      }
    },

    // ==================== DOCUMENTS ====================
    documents: {
      title: "Documents",
      myDocuments: "My Documents",
      uploadDocument: "Upload Document",
      
      // Types
      types: {
        w2: "W-2 Form",
        w2c: "W-2c Corrected Form",
        form1099: "1099 Form",
        form1099misc: "1099-MISC",
        form1099nec: "1099-NEC",
        form1099int: "1099-INT",
        form1099div: "1099-DIV",
        form1099b: "1099-B",
        form1099r: "1099-R",
        form1099g: "1099-G",
        form1098: "1098 Form",
        form1098e: "1098-E Student Loan",
        form1098t: "1098-T Tuition",
        taxReturn: "Tax Return",
        receipt: "Receipt",
        other: "Other"
      },
      
      // Status
      status: {
        uploaded: "Uploaded",
        processing: "Processing",
        verified: "Verified",
        error: "Error",
        pending: "Pending Review"
      },
      
      // Actions
      actions: {
        view: "View",
        download: "Download",
        delete: "Delete",
        rename: "Rename",
        share: "Share"
      },
      
      // Messages
      messages: {
        uploadSuccess: "Document uploaded successfully",
        uploadFailed: "Failed to upload document",
        deleteConfirm: "Are you sure you want to delete this document?",
        deleteSuccess: "Document deleted",
        noDocuments: "No documents uploaded yet",
        dragDrop: "Drag and drop files here",
        browseFiles: "Browse Files",
        maxSize: "Maximum file size: 10MB",
        supportedFormats: "Supported formats: PDF, JPG, PNG"
      }
    },

    // ==================== PROFILE / SETTINGS ====================
    profile: {
      title: "Profile",
      myProfile: "My Profile",
      editProfile: "Edit Profile",
      
      // Personal Info
      personalInfo: "Personal Information",
      firstName: "First Name",
      middleName: "Middle Name",
      lastName: "Last Name",
      suffix: "Suffix",
      dateOfBirth: "Date of Birth",
      ssn: "Social Security Number",
      phone: "Phone Number",
      email: "Email",
      
      // Address
      address: "Address",
      street: "Street Address",
      apartment: "Apt/Suite/Unit",
      city: "City",
      state: "State",
      zipCode: "ZIP Code",
      country: "Country",
      
      // Spouse
      spouse: "Spouse Information",
      spouseFirstName: "Spouse First Name",
      spouseLastName: "Spouse Last Name",
      spouseSSN: "Spouse SSN",
      spouseDOB: "Spouse Date of Birth",
      
      // Dependents
      dependents: "Dependents",
      addDependent: "Add Dependent",
      dependentName: "Dependent Name",
      dependentSSN: "Dependent SSN",
      dependentDOB: "Date of Birth",
      relationship: "Relationship",
      relationships: {
        child: "Child",
        stepchild: "Stepchild",
        fosterChild: "Foster Child",
        sibling: "Sibling",
        parent: "Parent",
        grandparent: "Grandparent",
        grandchild: "Grandchild",
        other: "Other"
      },
      
      // Bank Info
      bankInfo: "Bank Information",
      bankName: "Bank Name",
      accountType: "Account Type",
      routingNumber: "Routing Number",
      accountNumber: "Account Number",
      
      // Preferences
      preferences: "Preferences",
      language: "Language",
      notifications: "Notifications",
      emailNotifications: "Email Notifications",
      smsNotifications: "SMS Notifications",
      
      // Security
      security: "Security",
      changePassword: "Change Password",
      twoFactor: "Two-Factor Authentication",
      loginHistory: "Login History",
      
      // Messages
      messages: {
        saved: "Profile saved successfully",
        updated: "Profile updated",
        error: "Error saving profile"
      }
    },

    // ==================== ERRORS ====================
    errors: {
      generic: "Sorry, an error occurred. Please try again.",
      networkError: "Network error. Please check your connection.",
      serverError: "Server error. Please try again later.",
      notFound: "Page not found",
      unauthorized: "Please log in to continue",
      forbidden: "You don't have permission to access this",
      sessionExpired: "Your session has expired. Please log in again.",
      invalidInput: "Please check your input and try again",
      required: "This field is required",
      invalidEmail: "Please enter a valid email address",
      invalidPhone: "Please enter a valid phone number",
      invalidSSN: "Please enter a valid 9-digit SSN",
      invalidZip: "Please enter a valid ZIP code",
      invalidDate: "Please enter a valid date",
      fileTooLarge: "File is too large",
      unsupportedFormat: "Unsupported file format"
    },

    // ==================== SUCCESS MESSAGES ====================
    success: {
      saved: "Saved successfully",
      updated: "Updated successfully",
      deleted: "Deleted successfully",
      uploaded: "Uploaded successfully",
      submitted: "Submitted successfully",
      sent: "Sent successfully"
    },

    // ==================== FOOTER ====================
    footer: {
      copyright: "© {year} TaxSky. All rights reserved.",
      privacy: "Privacy Policy",
      terms: "Terms of Service",
      contact: "Contact Us",
      support: "Support",
      about: "About",
      faq: "FAQ"
    }
  },

  // ============================================================
  // VIETNAMESE
  // ============================================================
  vi: {
    // ==================== COMMON / SHARED ====================
    common: {
      appName: "TaxSky",
      tagline: "Khai Thuế Bằng AI",
      taxYear: "Năm Thuế",
      loading: "Đang tải...",
      save: "Lưu",
      cancel: "Hủy",
      close: "Đóng",
      back: "Quay lại",
      next: "Tiếp",
      continue: "Tiếp tục",
      submit: "Gửi",
      confirm: "Xác nhận",
      edit: "Sửa",
      delete: "Xóa",
      download: "Tải về",
      upload: "Tải lên",
      print: "In",
      refresh: "Làm mới",
      search: "Tìm kiếm",
      yes: "Có",
      no: "Không",
      ok: "OK",
      done: "Xong",
      or: "hoặc",
      and: "và",
      none: "Không có",
      notProvided: "Chưa có",
      notSelected: "Chưa chọn",
      required: "Bắt buộc",
      optional: "Tùy chọn",
      success: "Thành công",
      error: "Lỗi",
      warning: "Cảnh báo",
      info: "Thông tin"
    },

    // ==================== NAVIGATION ====================
    nav: {
      home: "Trang chủ",
      dashboard: "Bảng điều khiển",
      chat: "Chat với AI",
      fileReturn: "Nộp thuế",
      documents: "Tài liệu",
      payments: "Thanh toán",
      refundStatus: "Tình trạng hoàn thuế",
      profile: "Hồ sơ",
      settings: "Cài đặt",
      help: "Trợ giúp",
      logout: "Đăng xuất",
      login: "Đăng nhập",
      signup: "Đăng ký"
    },

    // ==================== AUTH ====================
    auth: {
      login: "Đăng nhập",
      signup: "Đăng ký",
      logout: "Đăng xuất",
      email: "Email",
      password: "Mật khẩu",
      confirmPassword: "Xác nhận mật khẩu",
      forgotPassword: "Quên mật khẩu?",
      resetPassword: "Đặt lại mật khẩu",
      rememberMe: "Ghi nhớ đăng nhập",
      noAccount: "Chưa có tài khoản?",
      hasAccount: "Đã có tài khoản?",
      loginSuccess: "Đăng nhập thành công!",
      logoutSuccess: "Đăng xuất thành công!",
      signupSuccess: "Tạo tài khoản thành công!",
      invalidCredentials: "Email hoặc mật khẩu không đúng",
      passwordMismatch: "Mật khẩu không khớp",
      emailRequired: "Vui lòng nhập email",
      passwordRequired: "Vui lòng nhập mật khẩu"
    },

    // ==================== SMART CHAT INTERFACE ====================
    chat: {
      title: "TaxSky AI",
      placeholder: "Hỏi tôi bất cứ điều gì về thuế của bạn...",
      send: "Gửi",
      uploading: "Đang tải",
      showData: "Xem dữ liệu",
      hideData: "Ẩn dữ liệu",
      startOver: "Làm lại",
      downloadForm: "Tải Mẫu 1040",
      yourTaxData: "Dữ liệu thuế của bạn",
      welcome: "👋 Xin chào! Tôi là TaxSky AI. Tôi có thể giúp gì cho bạn về thuế?",
      thinking: "Đang suy nghĩ...",
      typing: "TaxSky đang gõ...",
      quickActions: {
        uploadW2: "Tải W-2",
        filingStatus: "Tình trạng khai thuế",
        addDependent: "Thêm người phụ thuộc",
        checkRefund: "Kiểm tra hoàn thuế",
        fileReturn: "Nộp thuế",
        askQuestion: "Đặt câu hỏi"
      }
    },

    // ==================== DASHBOARD ====================
    dashboard: {
      title: "Bảng Điều Khiển Thuế",
      welcome: "Chào mừng trở lại",
      taxYear: "Năm Thuế {year}",
      overview: "Tổng quan",
      quickActions: "Thao tác nhanh",
      recentActivity: "Hoạt động gần đây",
      
      totalIncome: "Tổng thu nhập",
      totalDeductions: "Khấu trừ",
      estimatedRefund: "Hoàn thuế ước tính",
      amountOwed: "Số tiền nợ",
      taxesPaid: "Thuế đã đóng",
      
      status: "Trạng thái",
      notStarted: "Chưa bắt đầu",
      inProgress: "Đang tiến hành",
      readyToFile: "Sẵn sàng nộp",
      filed: "Đã nộp",
      accepted: "Đã chấp nhận",
      rejected: "Bị từ chối",
      
      startReturn: "Bắt đầu khai thuế",
      continueReturn: "Tiếp tục khai thuế",
      viewReturn: "Xem tờ khai",
      amendReturn: "Sửa đổi tờ khai",
      
      documents: "Tài liệu",
      uploadedDocs: "Tài liệu đã tải",
      w2Forms: "Mẫu W-2",
      form1099: "Mẫu 1099",
      otherDocs: "Tài liệu khác",
      noDocuments: "Chưa có tài liệu nào"
    },

    // ==================== FILE TAX RETURN WIZARD ====================
    fileReturn: {
      title: "Nộp Tờ Khai Thuế",
      
      steps: {
        step1: "Xem thông tin",
        step2: "Xác nhận thu nhập",
        step3: "Kiểm tra hoàn thuế",
        step4: "Xác nhận & Ký",
        step5: "Hoàn tất"
      },
      
      reviewInfo: {
        title: "Xem Lại Thông Tin Của Bạn",
        personalInfo: "Thông Tin Cá Nhân",
        name: "Họ tên",
        ssn: "Số An Sinh Xã Hội",
        address: "Địa chỉ",
        filingStatus: "Tình trạng khai thuế",
        dependents: "Người phụ thuộc",
        editInfo: "Sửa thông tin",
        addDependent: "Thêm người phụ thuộc",
        spouse: "Thông tin vợ/chồng"
      },
      
      verifyIncome: {
        title: "Xác Nhận Thu Nhập",
        w2Income: "Thu nhập W-2",
        form1099Income: "Thu nhập 1099",
        otherIncome: "Thu nhập khác",
        employer: "Công ty",
        wages: "Lương",
        federalWithheld: "Thuế Liên Bang đã khấu trừ",
        stateWithheld: "Thuế Tiểu Bang đã khấu trừ",
        totalIncome: "Tổng thu nhập",
        noW2: "Chưa tải W-2 lên",
        no1099: "Chưa tải 1099 lên",
        uploadW2: "Tải W-2 lên",
        upload1099: "Tải 1099 lên",
        addIncome: "Thêm thu nhập"
      },
      
      checkRefund: {
        title: "Tóm Tắt Thuế Của Bạn",
        federal: "Liên Bang",
        state: "Tiểu Bang",
        taxableIncome: "Thu nhập chịu thuế",
        adjustedGrossIncome: "Thu nhập gộp điều chỉnh",
        standardDeduction: "Khấu trừ tiêu chuẩn",
        itemizedDeductions: "Khấu trừ chi tiết",
        totalTax: "Tổng thuế",
        withheld: "Thuế đã khấu trừ",
        refund: "Hoàn thuế",
        owed: "Số tiền nợ",
        totalRefund: "Tổng hoàn thuế",
        totalOwed: "Tổng số tiền nợ",
        credits: "Tín dụng thuế",
        childTaxCredit: "Tín dụng thuế trẻ em",
        eitc: "Tín dụng thu nhập",
        otherCredits: "Tín dụng khác",
        effectiveRate: "Thuế suất thực tế",
        marginalRate: "Thuế suất biên"
      },
      
      confirmSign: {
        title: "Xác Nhận & Ký",
        reviewReturn: "Xem lại tờ khai",
        electronicSignature: "Chữ ký điện tử",
        signatureDisclaimer: "Bằng cách nhập mã PIN bên dưới, bạn đang ký tờ khai thuế điện tử. Bạn xác nhận rằng tất cả thông tin là đúng sự thật, chính xác và đầy đủ.",
        enterPin: "Nhập mã PIN 5 số",
        createPin: "Tạo mã PIN",
        confirmPin: "Xác nhận PIN",
        spouseSignature: "Chữ ký vợ/chồng",
        spousePin: "PIN vợ/chồng (nếu khai chung)",
        agreeTerms: "Tôi đồng ý với các điều khoản và điều kiện",
        agreePerjury: "Tôi tuyên bố dưới hình phạt khai man rằng tờ khai này là đúng và đầy đủ",
        irsDisclosure: "Dưới hình phạt khai man, tôi tuyên bố rằng tôi đã kiểm tra tờ khai này và các biểu mẫu kèm theo, và theo hiểu biết tốt nhất của tôi, chúng là đúng sự thật, chính xác và đầy đủ.",
        practitionerPin: "PIN người làm thuế (nếu có)",
        identityVerification: "Xác minh danh tính",
        securityQuestion: "Câu hỏi bảo mật"
      },
      
      complete: {
        title: "Nộp Thuế Hoàn Tất!",
        success: "Tờ khai thuế của bạn đã được nộp thành công.",
        congratulations: "Chúc mừng!",
        confirmationNumber: "Số xác nhận",
        submittedOn: "Ngày nộp",
        expectedRefund: "Hoàn thuế dự kiến",
        estimatedDate: "Ngày hoàn thuế ước tính",
        directDeposit: "Chuyển khoản trực tiếp",
        paperCheck: "Séc giấy",
        
        downloadReturn: "Tải tờ khai",
        download1040: "Tải Mẫu 1040",
        downloadReceipt: "Tải biên nhận",
        downloadAll: "Tải tất cả tài liệu",
        
        whatNext: "Bước tiếp theo?",
        checkStatus: "Kiểm tra tình trạng hoàn thuế",
        irsAcceptance: "IRS chấp nhận: Trong vòng 24-48 giờ",
        refundTime: "Hoàn thuế: 21 ngày (nộp điện tử + chuyển khoản)",
        trackRefund: "Theo dõi hoàn thuế tại irs.gov/refunds",
        printCopy: "In một bản để lưu hồ sơ",
        
        stateReturn: "Tờ khai Tiểu Bang",
        stateSubmitted: "Tờ khai tiểu bang cũng đã nộp",
        stateConfirmation: "Số xác nhận Tiểu Bang"
      },
      
      filingStatuses: {
        single: "Độc thân",
        married_filing_jointly: "Vợ chồng khai chung",
        married_filing_separately: "Vợ chồng khai riêng",
        head_of_household: "Chủ hộ",
        qualifying_widow: "Góa phụ/phu hợp lệ"
      },
      
      buttons: {
        cancel: "Hủy",
        back: "Quay lại",
        continue: "Tiếp tục",
        next: "Tiếp",
        submit: "Nộp tờ khai",
        sign: "Ký & Nộp",
        close: "Đóng",
        done: "Xong",
        edit: "Sửa",
        save: "Lưu",
        print: "In",
        download: "Tải về",
        fileNow: "Nộp ngay",
        payNow: "Thanh toán ngay",
        reviewReturn: "Xem lại tờ khai"
      },
      
      errors: {
        required: "Trường này bắt buộc",
        invalidPin: "PIN phải có 5 chữ số",
        pinMismatch: "PIN không khớp",
        mustAgree: "Bạn phải đồng ý với các điều khoản",
        submitFailed: "Nộp thất bại. Vui lòng thử lại.",
        incompleteInfo: "Vui lòng hoàn thành tất cả thông tin bắt buộc",
        invalidSSN: "Số SSN không hợp lệ",
        missingW2: "Vui lòng tải lên ít nhất một W-2",
        missingSignature: "Cần có chữ ký"
      },
      
      confirmations: {
        cancelFiling: "Bạn có chắc muốn hủy? Tiến trình của bạn sẽ bị mất.",
        submitReturn: "Bạn đã sẵn sàng nộp tờ khai thuế chưa?",
        deleteDocument: "Bạn có chắc muốn xóa tài liệu này?"
      }
    },

    // ==================== PAYMENT ====================
    payment: {
      title: "Thanh Toán",
      payTaxes: "Thanh Toán Thuế",
      paymentMethod: "Phương thức thanh toán",
      
      amountDue: "Số tiền cần thanh toán",
      totalDue: "Tổng cộng",
      federalTax: "Thuế Liên Bang",
      stateTax: "Thuế Tiểu Bang",
      penalties: "Phạt",
      interest: "Lãi",
      serviceFee: "Phí dịch vụ",
      processingFee: "Phí xử lý",
      
      methods: {
        title: "Chọn phương thức thanh toán",
        creditCard: "Thẻ tín dụng/ghi nợ",
        bankAccount: "Tài khoản ngân hàng (ACH)",
        directDebit: "Ghi nợ trực tiếp",
        paypal: "PayPal",
        applePay: "Apple Pay",
        googlePay: "Google Pay",
        check: "Gửi séc qua đường bưu điện",
        installment: "Trả góp"
      },
      
      card: {
        cardNumber: "Số thẻ",
        cardHolder: "Tên chủ thẻ",
        expiryDate: "Ngày hết hạn",
        cvv: "CVV",
        billingAddress: "Địa chỉ thanh toán",
        saveCard: "Lưu thẻ cho lần thanh toán sau"
      },
      
      bank: {
        accountType: "Loại tài khoản",
        checking: "Tài khoản vãng lai",
        savings: "Tài khoản tiết kiệm",
        routingNumber: "Số định tuyến",
        accountNumber: "Số tài khoản",
        confirmAccount: "Xác nhận số tài khoản",
        bankName: "Tên ngân hàng"
      },
      
      installment: {
        title: "Kế hoạch trả góp",
        monthlyPayment: "Thanh toán hàng tháng",
        numberOfPayments: "Số lần thanh toán",
        startDate: "Ngày bắt đầu",
        setupFee: "Phí thiết lập",
        terms: "Điều khoản trả góp"
      },
      
      status: {
        pending: "Đang chờ",
        processing: "Đang xử lý",
        completed: "Hoàn thành",
        failed: "Thất bại",
        refunded: "Đã hoàn tiền",
        cancelled: "Đã hủy"
      },
      
      buttons: {
        pay: "Thanh toán",
        payNow: "Thanh toán ngay",
        submitPayment: "Gửi thanh toán",
        schedulePayment: "Lên lịch thanh toán",
        setupPlan: "Thiết lập kế hoạch trả góp",
        viewHistory: "Xem lịch sử thanh toán",
        downloadReceipt: "Tải biên nhận"
      },
      
      messages: {
        success: "Thanh toán thành công!",
        failed: "Thanh toán thất bại. Vui lòng thử lại.",
        processing: "Đang xử lý thanh toán...",
        confirmation: "Xác nhận thanh toán",
        receiptSent: "Biên nhận đã gửi đến email của bạn",
        thankYou: "Cảm ơn bạn đã thanh toán!"
      },
      
      errors: {
        invalidCard: "Số thẻ không hợp lệ",
        expiredCard: "Thẻ đã hết hạn",
        invalidCvv: "CVV không hợp lệ",
        invalidRouting: "Số định tuyến không hợp lệ",
        invalidAccount: "Số tài khoản không hợp lệ",
        accountMismatch: "Số tài khoản không khớp",
        insufficientFunds: "Không đủ tiền",
        paymentDeclined: "Thanh toán bị từ chối",
        tryAgain: "Vui lòng thử lại hoặc sử dụng phương thức thanh toán khác"
      }
    },

    // ==================== CHECK REFUND / TAX STATUS ====================
    refundStatus: {
      title: "Tình Trạng Hoàn Thuế",
      checkStatus: "Kiểm Tra Tình Trạng Hoàn Thuế",
      trackRefund: "Theo Dõi Hoàn Thuế",
      
      enterInfo: "Nhập thông tin để kiểm tra",
      ssn: "Số An Sinh Xã Hội",
      filingStatus: "Tình trạng khai thuế",
      refundAmount: "Số tiền hoàn thuế dự kiến",
      
      steps: {
        received: "Đã nhận tờ khai",
        approved: "Đã duyệt hoàn thuế",
        sent: "Đã gửi hoàn thuế"
      },
      
      status: {
        notFiled: "Chưa nộp tờ khai",
        received: "Đã nhận tờ khai",
        processing: "Đang xử lý",
        approved: "Đã duyệt hoàn thuế",
        sent: "Đã gửi hoàn thuế",
        deposited: "Đã chuyển khoản hoàn thuế",
        mailed: "Đã gửi séc",
        delayed: "Bị chậm trễ",
        underReview: "Đang xem xét",
        actionRequired: "Cần hành động"
      },
      
      details: {
        confirmationNumber: "Số xác nhận",
        dateFiled: "Ngày nộp",
        dateAccepted: "Ngày chấp nhận",
        expectedDate: "Ngày dự kiến",
        actualDate: "Ngày thực tế",
        amount: "Số tiền hoàn thuế",
        method: "Phương thức nhận",
        directDeposit: "Chuyển khoản trực tiếp",
        paperCheck: "Séc giấy",
        bankAccount: "Tài khoản ngân hàng kết thúc bằng",
        mailingAddress: "Địa chỉ nhận thư"
      },
      
      federal: {
        title: "Hoàn thuế Liên Bang",
        status: "Trạng thái Liên Bang",
        irsStatus: "Trạng thái IRS"
      },
      state: {
        title: "Hoàn thuế Tiểu Bang",
        status: "Trạng thái Tiểu Bang"
      },
      
      messages: {
        checkBack: "Kiểm tra lại sau 24-48 giờ để cập nhật",
        typical21Days: "Hầu hết hoàn thuế được xử lý trong vòng 21 ngày",
        contactIRS: "Liên hệ IRS nếu đã quá 21 ngày",
        whereMyRefund: "Để biết thêm chi tiết, truy cập irs.gov/refunds",
        noRecord: "Không tìm thấy hồ sơ. Vui lòng kiểm tra lại thông tin.",
        stillProcessing: "Tờ khai của bạn vẫn đang được xử lý"
      },
      
      buttons: {
        check: "Kiểm tra",
        refresh: "Làm mới",
        viewDetails: "Xem chi tiết",
        contactSupport: "Liên hệ hỗ trợ",
        visitIRS: "Truy cập IRS.gov"
      }
    },

    // ==================== DOCUMENTS ====================
    documents: {
      title: "Tài Liệu",
      myDocuments: "Tài liệu của tôi",
      uploadDocument: "Tải tài liệu lên",
      
      types: {
        w2: "Mẫu W-2",
        w2c: "Mẫu W-2c Đã sửa",
        form1099: "Mẫu 1099",
        form1099misc: "1099-MISC",
        form1099nec: "1099-NEC",
        form1099int: "1099-INT",
        form1099div: "1099-DIV",
        form1099b: "1099-B",
        form1099r: "1099-R",
        form1099g: "1099-G",
        form1098: "Mẫu 1098",
        form1098e: "1098-E Vay sinh viên",
        form1098t: "1098-T Học phí",
        taxReturn: "Tờ khai thuế",
        receipt: "Biên nhận",
        other: "Khác"
      },
      
      status: {
        uploaded: "Đã tải lên",
        processing: "Đang xử lý",
        verified: "Đã xác minh",
        error: "Lỗi",
        pending: "Đang chờ xem xét"
      },
      
      actions: {
        view: "Xem",
        download: "Tải về",
        delete: "Xóa",
        rename: "Đổi tên",
        share: "Chia sẻ"
      },
      
      messages: {
        uploadSuccess: "Tải tài liệu thành công",
        uploadFailed: "Tải tài liệu thất bại",
        deleteConfirm: "Bạn có chắc muốn xóa tài liệu này?",
        deleteSuccess: "Đã xóa tài liệu",
        noDocuments: "Chưa có tài liệu nào",
        dragDrop: "Kéo và thả tệp vào đây",
        browseFiles: "Chọn tệp",
        maxSize: "Kích thước tối đa: 10MB",
        supportedFormats: "Định dạng hỗ trợ: PDF, JPG, PNG"
      }
    },

    // ==================== PROFILE / SETTINGS ====================
    profile: {
      title: "Hồ Sơ",
      myProfile: "Hồ sơ của tôi",
      editProfile: "Sửa hồ sơ",
      
      personalInfo: "Thông tin cá nhân",
      firstName: "Tên",
      middleName: "Tên đệm",
      lastName: "Họ",
      suffix: "Hậu tố",
      dateOfBirth: "Ngày sinh",
      ssn: "Số An Sinh Xã Hội",
      phone: "Số điện thoại",
      email: "Email",
      
      address: "Địa chỉ",
      street: "Địa chỉ đường",
      apartment: "Căn hộ/Phòng",
      city: "Thành phố",
      state: "Tiểu bang",
      zipCode: "Mã bưu điện",
      country: "Quốc gia",
      
      spouse: "Thông tin vợ/chồng",
      spouseFirstName: "Tên vợ/chồng",
      spouseLastName: "Họ vợ/chồng",
      spouseSSN: "SSN vợ/chồng",
      spouseDOB: "Ngày sinh vợ/chồng",
      
      dependents: "Người phụ thuộc",
      addDependent: "Thêm người phụ thuộc",
      dependentName: "Tên người phụ thuộc",
      dependentSSN: "SSN người phụ thuộc",
      dependentDOB: "Ngày sinh",
      relationship: "Quan hệ",
      relationships: {
        child: "Con",
        stepchild: "Con riêng",
        fosterChild: "Con nuôi",
        sibling: "Anh chị em",
        parent: "Cha mẹ",
        grandparent: "Ông bà",
        grandchild: "Cháu",
        other: "Khác"
      },
      
      bankInfo: "Thông tin ngân hàng",
      bankName: "Tên ngân hàng",
      accountType: "Loại tài khoản",
      routingNumber: "Số định tuyến",
      accountNumber: "Số tài khoản",
      
      preferences: "Tùy chọn",
      language: "Ngôn ngữ",
      notifications: "Thông báo",
      emailNotifications: "Thông báo email",
      smsNotifications: "Thông báo SMS",
      
      security: "Bảo mật",
      changePassword: "Đổi mật khẩu",
      twoFactor: "Xác thực hai yếu tố",
      loginHistory: "Lịch sử đăng nhập",
      
      messages: {
        saved: "Đã lưu hồ sơ thành công",
        updated: "Đã cập nhật hồ sơ",
        error: "Lỗi khi lưu hồ sơ"
      }
    },

    // ==================== ERRORS ====================
    errors: {
      generic: "Xin lỗi, đã có lỗi xảy ra. Vui lòng thử lại.",
      networkError: "Lỗi mạng. Vui lòng kiểm tra kết nối.",
      serverError: "Lỗi máy chủ. Vui lòng thử lại sau.",
      notFound: "Không tìm thấy trang",
      unauthorized: "Vui lòng đăng nhập để tiếp tục",
      forbidden: "Bạn không có quyền truy cập",
      sessionExpired: "Phiên đã hết hạn. Vui lòng đăng nhập lại.",
      invalidInput: "Vui lòng kiểm tra dữ liệu nhập và thử lại",
      required: "Trường này bắt buộc",
      invalidEmail: "Vui lòng nhập email hợp lệ",
      invalidPhone: "Vui lòng nhập số điện thoại hợp lệ",
      invalidSSN: "Vui lòng nhập số SSN 9 chữ số hợp lệ",
      invalidZip: "Vui lòng nhập mã ZIP hợp lệ",
      invalidDate: "Vui lòng nhập ngày hợp lệ",
      fileTooLarge: "Tệp quá lớn",
      unsupportedFormat: "Định dạng tệp không được hỗ trợ"
    },

    // ==================== SUCCESS MESSAGES ====================
    success: {
      saved: "Đã lưu thành công",
      updated: "Đã cập nhật thành công",
      deleted: "Đã xóa thành công",
      uploaded: "Đã tải lên thành công",
      submitted: "Đã gửi thành công",
      sent: "Đã gửi thành công"
    },

    // ==================== FOOTER ====================
    footer: {
      copyright: "© {year} TaxSky. Bảo lưu mọi quyền.",
      privacy: "Chính sách bảo mật",
      terms: "Điều khoản dịch vụ",
      contact: "Liên hệ",
      support: "Hỗ trợ",
      about: "Giới thiệu",
      faq: "Câu hỏi thường gặp"
    }
  },

  // ============================================================
  // SPANISH
  // ============================================================
  es: {
    // ==================== COMMON / SHARED ====================
    common: {
      appName: "TaxSky",
      tagline: "Declaración de Impuestos con IA",
      taxYear: "Año Fiscal",
      loading: "Cargando...",
      save: "Guardar",
      cancel: "Cancelar",
      close: "Cerrar",
      back: "Atrás",
      next: "Siguiente",
      continue: "Continuar",
      submit: "Enviar",
      confirm: "Confirmar",
      edit: "Editar",
      delete: "Eliminar",
      download: "Descargar",
      upload: "Subir",
      print: "Imprimir",
      refresh: "Actualizar",
      search: "Buscar",
      yes: "Sí",
      no: "No",
      ok: "OK",
      done: "Listo",
      or: "o",
      and: "y",
      none: "Ninguno",
      notProvided: "No proporcionado",
      notSelected: "No seleccionado",
      required: "Requerido",
      optional: "Opcional",
      success: "Éxito",
      error: "Error",
      warning: "Advertencia",
      info: "Información"
    },

    // ==================== NAVIGATION ====================
    nav: {
      home: "Inicio",
      dashboard: "Panel",
      chat: "Chat con IA",
      fileReturn: "Presentar Declaración",
      documents: "Documentos",
      payments: "Pagos",
      refundStatus: "Estado del Reembolso",
      profile: "Perfil",
      settings: "Configuración",
      help: "Ayuda",
      logout: "Cerrar Sesión",
      login: "Iniciar Sesión",
      signup: "Registrarse"
    },

    // ==================== AUTH ====================
    auth: {
      login: "Iniciar Sesión",
      signup: "Registrarse",
      logout: "Cerrar Sesión",
      email: "Correo electrónico",
      password: "Contraseña",
      confirmPassword: "Confirmar contraseña",
      forgotPassword: "¿Olvidaste tu contraseña?",
      resetPassword: "Restablecer contraseña",
      rememberMe: "Recordarme",
      noAccount: "¿No tienes cuenta?",
      hasAccount: "¿Ya tienes cuenta?",
      loginSuccess: "¡Sesión iniciada correctamente!",
      logoutSuccess: "¡Sesión cerrada correctamente!",
      signupSuccess: "¡Cuenta creada correctamente!",
      invalidCredentials: "Correo o contraseña inválidos",
      passwordMismatch: "Las contraseñas no coinciden",
      emailRequired: "El correo es requerido",
      passwordRequired: "La contraseña es requerida"
    },

    // ==================== SMART CHAT INTERFACE ====================
    chat: {
      title: "TaxSky AI",
      placeholder: "Pregúntame cualquier cosa sobre tus impuestos...",
      send: "Enviar",
      uploading: "Subiendo",
      showData: "Ver datos",
      hideData: "Ocultar datos",
      startOver: "Empezar de nuevo",
      downloadForm: "Descargar 1040",
      yourTaxData: "Tus datos fiscales",
      welcome: "👋 ¡Hola! Soy TaxSky AI. ¿Cómo puedo ayudarte con tus impuestos?",
      thinking: "Pensando...",
      typing: "TaxSky está escribiendo...",
      quickActions: {
        uploadW2: "Subir W-2",
        filingStatus: "Estado civil",
        addDependent: "Agregar dependiente",
        checkRefund: "Ver reembolso",
        fileReturn: "Presentar declaración",
        askQuestion: "Hacer pregunta"
      }
    },

    // ==================== DASHBOARD ====================
    dashboard: {
      title: "Panel de Impuestos",
      welcome: "Bienvenido/a de nuevo",
      taxYear: "Año Fiscal {year}",
      overview: "Resumen",
      quickActions: "Acciones rápidas",
      recentActivity: "Actividad reciente",
      
      totalIncome: "Ingreso total",
      totalDeductions: "Deducciones",
      estimatedRefund: "Reembolso estimado",
      amountOwed: "Cantidad adeudada",
      taxesPaid: "Impuestos pagados",
      
      status: "Estado",
      notStarted: "No iniciado",
      inProgress: "En progreso",
      readyToFile: "Listo para presentar",
      filed: "Presentado",
      accepted: "Aceptado",
      rejected: "Rechazado",
      
      startReturn: "Iniciar declaración",
      continueReturn: "Continuar declaración",
      viewReturn: "Ver declaración",
      amendReturn: "Enmendar declaración",
      
      documents: "Documentos",
      uploadedDocs: "Documentos subidos",
      w2Forms: "Formularios W-2",
      form1099: "Formularios 1099",
      otherDocs: "Otros documentos",
      noDocuments: "No hay documentos subidos"
    },

    // ==================== FILE TAX RETURN WIZARD ====================
    fileReturn: {
      title: "Presentar Tu Declaración",
      
      steps: {
        step1: "Revisar info",
        step2: "Verificar ingresos",
        step3: "Ver reembolso",
        step4: "Confirmar y firmar",
        step5: "Completar"
      },
      
      reviewInfo: {
        title: "Revisa Tu Información",
        personalInfo: "Información Personal",
        name: "Nombre",
        ssn: "Número de Seguro Social",
        address: "Dirección",
        filingStatus: "Estado civil tributario",
        dependents: "Dependientes",
        editInfo: "Editar información",
        addDependent: "Agregar dependiente",
        spouse: "Información del cónyuge"
      },
      
      verifyIncome: {
        title: "Verifica Tus Ingresos",
        w2Income: "Ingresos W-2",
        form1099Income: "Ingresos 1099",
        otherIncome: "Otros ingresos",
        employer: "Empleador",
        wages: "Salarios",
        federalWithheld: "Impuesto Federal retenido",
        stateWithheld: "Impuesto Estatal retenido",
        totalIncome: "Ingreso total",
        noW2: "No se ha subido W-2",
        no1099: "No se ha subido 1099",
        uploadW2: "Subir W-2",
        upload1099: "Subir 1099",
        addIncome: "Agregar ingreso"
      },
      
      checkRefund: {
        title: "Resumen de Impuestos",
        federal: "Federal",
        state: "Estatal",
        taxableIncome: "Ingreso gravable",
        adjustedGrossIncome: "Ingreso bruto ajustado",
        standardDeduction: "Deducción estándar",
        itemizedDeductions: "Deducciones detalladas",
        totalTax: "Impuesto total",
        withheld: "Impuesto retenido",
        refund: "Reembolso",
        owed: "Cantidad adeudada",
        totalRefund: "Reembolso total",
        totalOwed: "Total adeudado",
        credits: "Créditos fiscales",
        childTaxCredit: "Crédito tributario por hijos",
        eitc: "Crédito por ingreso del trabajo",
        otherCredits: "Otros créditos",
        effectiveRate: "Tasa efectiva",
        marginalRate: "Tasa marginal"
      },
      
      confirmSign: {
        title: "Confirmar y Firmar",
        reviewReturn: "Revisar declaración",
        electronicSignature: "Firma electrónica",
        signatureDisclaimer: "Al ingresar tu PIN abajo, estás firmando tu declaración electrónicamente. Confirmas que toda la información es verdadera, correcta y completa.",
        enterPin: "Ingresa PIN de 5 dígitos",
        createPin: "Crear PIN",
        confirmPin: "Confirmar PIN",
        spouseSignature: "Firma del cónyuge",
        spousePin: "PIN del cónyuge (si presentan juntos)",
        agreeTerms: "Acepto los términos y condiciones",
        agreePerjury: "Declaro bajo pena de perjurio que esta declaración es verdadera y completa",
        irsDisclosure: "Bajo pena de perjurio, declaro que he examinado esta declaración y los anexos adjuntos, y según mi leal saber y entender, son verdaderos, correctos y completos.",
        practitionerPin: "PIN del preparador (si aplica)",
        identityVerification: "Verificación de identidad",
        securityQuestion: "Pregunta de seguridad"
      },
      
      complete: {
        title: "¡Presentación Completa!",
        success: "Tu declaración ha sido enviada exitosamente.",
        congratulations: "¡Felicidades!",
        confirmationNumber: "Número de confirmación",
        submittedOn: "Enviado el",
        expectedRefund: "Reembolso esperado",
        estimatedDate: "Fecha estimada de reembolso",
        directDeposit: "Depósito directo",
        paperCheck: "Cheque en papel",
        
        downloadReturn: "Descargar declaración",
        download1040: "Descargar Formulario 1040",
        downloadReceipt: "Descargar recibo",
        downloadAll: "Descargar todos los documentos",
        
        whatNext: "¿Qué sigue?",
        checkStatus: "Verificar estado del reembolso",
        irsAcceptance: "Aceptación del IRS: Dentro de 24-48 horas",
        refundTime: "Reembolso: 21 días (e-file + depósito directo)",
        trackRefund: "Rastrea tu reembolso en irs.gov/refunds",
        printCopy: "Imprime una copia para tus registros",
        
        stateReturn: "Declaración estatal",
        stateSubmitted: "Declaración estatal también enviada",
        stateConfirmation: "Número de confirmación estatal"
      },
      
      filingStatuses: {
        single: "Soltero/a",
        married_filing_jointly: "Casado/a declarando juntos",
        married_filing_separately: "Casado/a declarando separado",
        head_of_household: "Jefe/a de familia",
        qualifying_widow: "Viudo/a calificado/a"
      },
      
      buttons: {
        cancel: "Cancelar",
        back: "Atrás",
        continue: "Continuar",
        next: "Siguiente",
        submit: "Enviar declaración",
        sign: "Firmar y enviar",
        close: "Cerrar",
        done: "Listo",
        edit: "Editar",
        save: "Guardar",
        print: "Imprimir",
        download: "Descargar",
        fileNow: "Presentar ahora",
        payNow: "Pagar ahora",
        reviewReturn: "Revisar declaración"
      },
      
      errors: {
        required: "Este campo es requerido",
        invalidPin: "El PIN debe tener 5 dígitos",
        pinMismatch: "Los PINs no coinciden",
        mustAgree: "Debes aceptar los términos",
        submitFailed: "Error al enviar. Por favor intenta de nuevo.",
        incompleteInfo: "Por favor completa toda la información requerida",
        invalidSSN: "Formato de SSN inválido",
        missingW2: "Por favor sube al menos un W-2",
        missingSignature: "Se requiere firma"
      },
      
      confirmations: {
        cancelFiling: "¿Estás seguro que quieres cancelar? Tu progreso se perderá.",
        submitReturn: "¿Estás listo para enviar tu declaración?",
        deleteDocument: "¿Estás seguro que quieres eliminar este documento?"
      }
    },

    // ==================== PAYMENT ====================
    payment: {
      title: "Pago",
      payTaxes: "Pagar Tus Impuestos",
      paymentMethod: "Método de pago",
      
      amountDue: "Cantidad a pagar",
      totalDue: "Total a pagar",
      federalTax: "Impuesto Federal",
      stateTax: "Impuesto Estatal",
      penalties: "Multas",
      interest: "Intereses",
      serviceFee: "Tarifa de servicio",
      processingFee: "Tarifa de procesamiento",
      
      methods: {
        title: "Selecciona método de pago",
        creditCard: "Tarjeta de crédito/débito",
        bankAccount: "Cuenta bancaria (ACH)",
        directDebit: "Débito directo",
        paypal: "PayPal",
        applePay: "Apple Pay",
        googlePay: "Google Pay",
        check: "Enviar cheque por correo",
        installment: "Plan de pagos"
      },
      
      card: {
        cardNumber: "Número de tarjeta",
        cardHolder: "Nombre del titular",
        expiryDate: "Fecha de vencimiento",
        cvv: "CVV",
        billingAddress: "Dirección de facturación",
        saveCard: "Guardar tarjeta para futuros pagos"
      },
      
      bank: {
        accountType: "Tipo de cuenta",
        checking: "Corriente",
        savings: "Ahorros",
        routingNumber: "Número de ruta",
        accountNumber: "Número de cuenta",
        confirmAccount: "Confirmar número de cuenta",
        bankName: "Nombre del banco"
      },
      
      installment: {
        title: "Plan de pagos",
        monthlyPayment: "Pago mensual",
        numberOfPayments: "Número de pagos",
        startDate: "Fecha de inicio",
        setupFee: "Tarifa de configuración",
        terms: "Términos del plan de pagos"
      },
      
      status: {
        pending: "Pendiente",
        processing: "Procesando",
        completed: "Completado",
        failed: "Fallido",
        refunded: "Reembolsado",
        cancelled: "Cancelado"
      },
      
      buttons: {
        pay: "Pagar",
        payNow: "Pagar ahora",
        submitPayment: "Enviar pago",
        schedulePayment: "Programar pago",
        setupPlan: "Configurar plan de pagos",
        viewHistory: "Ver historial de pagos",
        downloadReceipt: "Descargar recibo"
      },
      
      messages: {
        success: "¡Pago exitoso!",
        failed: "Pago fallido. Por favor intenta de nuevo.",
        processing: "Procesando tu pago...",
        confirmation: "Confirmación de pago",
        receiptSent: "Recibo enviado a tu correo",
        thankYou: "¡Gracias por tu pago!"
      },
      
      errors: {
        invalidCard: "Número de tarjeta inválido",
        expiredCard: "La tarjeta ha expirado",
        invalidCvv: "CVV inválido",
        invalidRouting: "Número de ruta inválido",
        invalidAccount: "Número de cuenta inválido",
        accountMismatch: "Los números de cuenta no coinciden",
        insufficientFunds: "Fondos insuficientes",
        paymentDeclined: "Pago rechazado",
        tryAgain: "Por favor intenta de nuevo o usa otro método de pago"
      }
    },

    // ==================== CHECK REFUND / TAX STATUS ====================
    refundStatus: {
      title: "Estado del Reembolso",
      checkStatus: "Verificar Estado del Reembolso",
      trackRefund: "Rastrear Tu Reembolso",
      
      enterInfo: "Ingresa tu información para verificar",
      ssn: "Número de Seguro Social",
      filingStatus: "Estado civil tributario",
      refundAmount: "Cantidad de reembolso esperada",
      
      steps: {
        received: "Declaración recibida",
        approved: "Reembolso aprobado",
        sent: "Reembolso enviado"
      },
      
      status: {
        notFiled: "Declaración no presentada",
        received: "Declaración recibida",
        processing: "En proceso",
        approved: "Reembolso aprobado",
        sent: "Reembolso enviado",
        deposited: "Reembolso depositado",
        mailed: "Cheque enviado",
        delayed: "Procesamiento retrasado",
        underReview: "En revisión",
        actionRequired: "Acción requerida"
      },
      
      details: {
        confirmationNumber: "Número de confirmación",
        dateFiled: "Fecha de presentación",
        dateAccepted: "Fecha de aceptación",
        expectedDate: "Fecha esperada",
        actualDate: "Fecha real",
        amount: "Cantidad del reembolso",
        method: "Método de entrega",
        directDeposit: "Depósito directo",
        paperCheck: "Cheque en papel",
        bankAccount: "Cuenta bancaria terminada en",
        mailingAddress: "Dirección de envío"
      },
      
      federal: {
        title: "Reembolso Federal",
        status: "Estado Federal",
        irsStatus: "Estado del IRS"
      },
      state: {
        title: "Reembolso Estatal",
        status: "Estado Estatal"
      },
      
      messages: {
        checkBack: "Revisa de nuevo en 24-48 horas para actualizaciones",
        typical21Days: "La mayoría de los reembolsos se emiten en 21 días",
        contactIRS: "Contacta al IRS si han pasado más de 21 días",
        whereMyRefund: "Para más detalles, visita irs.gov/refunds",
        noRecord: "No se encontró registro. Por favor verifica tu información.",
        stillProcessing: "Tu declaración aún está siendo procesada"
      },
      
      buttons: {
        check: "Verificar",
        refresh: "Actualizar",
        viewDetails: "Ver detalles",
        contactSupport: "Contactar soporte",
        visitIRS: "Visitar IRS.gov"
      }
    },

    // ==================== DOCUMENTS ====================
    documents: {
      title: "Documentos",
      myDocuments: "Mis documentos",
      uploadDocument: "Subir documento",
      
      types: {
        w2: "Formulario W-2",
        w2c: "Formulario W-2c Corregido",
        form1099: "Formulario 1099",
        form1099misc: "1099-MISC",
        form1099nec: "1099-NEC",
        form1099int: "1099-INT",
        form1099div: "1099-DIV",
        form1099b: "1099-B",
        form1099r: "1099-R",
        form1099g: "1099-G",
        form1098: "Formulario 1098",
        form1098e: "1098-E Préstamo estudiantil",
        form1098t: "1098-T Matrícula",
        taxReturn: "Declaración de impuestos",
        receipt: "Recibo",
        other: "Otro"
      },
      
      status: {
        uploaded: "Subido",
        processing: "Procesando",
        verified: "Verificado",
        error: "Error",
        pending: "Pendiente de revisión"
      },
      
      actions: {
        view: "Ver",
        download: "Descargar",
        delete: "Eliminar",
        rename: "Renombrar",
        share: "Compartir"
      },
      
      messages: {
        uploadSuccess: "Documento subido exitosamente",
        uploadFailed: "Error al subir documento",
        deleteConfirm: "¿Estás seguro que quieres eliminar este documento?",
        deleteSuccess: "Documento eliminado",
        noDocuments: "No hay documentos subidos",
        dragDrop: "Arrastra y suelta archivos aquí",
        browseFiles: "Explorar archivos",
        maxSize: "Tamaño máximo: 10MB",
        supportedFormats: "Formatos soportados: PDF, JPG, PNG"
      }
    },

    // ==================== PROFILE / SETTINGS ====================
    profile: {
      title: "Perfil",
      myProfile: "Mi perfil",
      editProfile: "Editar perfil",
      
      personalInfo: "Información personal",
      firstName: "Nombre",
      middleName: "Segundo nombre",
      lastName: "Apellido",
      suffix: "Sufijo",
      dateOfBirth: "Fecha de nacimiento",
      ssn: "Número de Seguro Social",
      phone: "Teléfono",
      email: "Correo electrónico",
      
      address: "Dirección",
      street: "Calle",
      apartment: "Apt/Suite/Unidad",
      city: "Ciudad",
      state: "Estado",
      zipCode: "Código postal",
      country: "País",
      
      spouse: "Información del cónyuge",
      spouseFirstName: "Nombre del cónyuge",
      spouseLastName: "Apellido del cónyuge",
      spouseSSN: "SSN del cónyuge",
      spouseDOB: "Fecha de nacimiento del cónyuge",
      
      dependents: "Dependientes",
      addDependent: "Agregar dependiente",
      dependentName: "Nombre del dependiente",
      dependentSSN: "SSN del dependiente",
      dependentDOB: "Fecha de nacimiento",
      relationship: "Relación",
      relationships: {
        child: "Hijo/a",
        stepchild: "Hijastro/a",
        fosterChild: "Hijo/a adoptivo/a",
        sibling: "Hermano/a",
        parent: "Padre/Madre",
        grandparent: "Abuelo/a",
        grandchild: "Nieto/a",
        other: "Otro"
      },
      
      bankInfo: "Información bancaria",
      bankName: "Nombre del banco",
      accountType: "Tipo de cuenta",
      routingNumber: "Número de ruta",
      accountNumber: "Número de cuenta",
      
      preferences: "Preferencias",
      language: "Idioma",
      notifications: "Notificaciones",
      emailNotifications: "Notificaciones por correo",
      smsNotifications: "Notificaciones SMS",
      
      security: "Seguridad",
      changePassword: "Cambiar contraseña",
      twoFactor: "Autenticación de dos factores",
      loginHistory: "Historial de inicio de sesión",
      
      messages: {
        saved: "Perfil guardado exitosamente",
        updated: "Perfil actualizado",
        error: "Error al guardar perfil"
      }
    },

    // ==================== ERRORS ====================
    errors: {
      generic: "Lo siento, ocurrió un error. Por favor intenta de nuevo.",
      networkError: "Error de red. Por favor verifica tu conexión.",
      serverError: "Error del servidor. Por favor intenta más tarde.",
      notFound: "Página no encontrada",
      unauthorized: "Por favor inicia sesión para continuar",
      forbidden: "No tienes permiso para acceder",
      sessionExpired: "Tu sesión ha expirado. Por favor inicia sesión de nuevo.",
      invalidInput: "Por favor verifica tu entrada e intenta de nuevo",
      required: "Este campo es requerido",
      invalidEmail: "Por favor ingresa un correo válido",
      invalidPhone: "Por favor ingresa un teléfono válido",
      invalidSSN: "Por favor ingresa un SSN válido de 9 dígitos",
      invalidZip: "Por favor ingresa un código postal válido",
      invalidDate: "Por favor ingresa una fecha válida",
      fileTooLarge: "El archivo es muy grande",
      unsupportedFormat: "Formato de archivo no soportado"
    },

    // ==================== SUCCESS MESSAGES ====================
    success: {
      saved: "Guardado exitosamente",
      updated: "Actualizado exitosamente",
      deleted: "Eliminado exitosamente",
      uploaded: "Subido exitosamente",
      submitted: "Enviado exitosamente",
      sent: "Enviado exitosamente"
    },

    // ==================== FOOTER ====================
    footer: {
      copyright: "© {year} TaxSky. Todos los derechos reservados.",
      privacy: "Política de privacidad",
      terms: "Términos de servicio",
      contact: "Contáctanos",
      support: "Soporte",
      about: "Acerca de",
      faq: "Preguntas frecuentes"
    }
  }
};

// ============================================================
// HELPER FUNCTIONS
// ============================================================

/**
 * Get translations for a language
 */
export function t(lang = 'en') {
  return translations[lang] || translations.en;
}

/**
 * Get a specific translation with variable replacement
 * Example: getText('en', 'common.taxYear') => "Tax Year"
 * Example: getText('en', 'dashboard.taxYear', { year: 2024 }) => "Tax Year 2024"
 */
export function getText(lang, path, vars = {}) {
  const langData = translations[lang] || translations.en;
  const keys = path.split('.');
  
  let value = langData;
  for (const key of keys) {
    value = value?.[key];
    if (value === undefined) {
      // Fallback to English
      value = translations.en;
      for (const k of keys) {
        value = value?.[k];
        if (value === undefined) return path;
      }
      break;
    }
  }
  
  if (typeof value !== 'string') return path;
  
  // Replace variables like {year}, {name}
  for (const [varName, val] of Object.entries(vars)) {
    value = value.replace(new RegExp(`\\{${varName}\\}`, 'g'), val);
  }
  
  return value;
}

/**
 * Get language display name
 */
export function getLanguageName(code) {
  const names = {
    en: 'English',
    vi: 'Tiếng Việt',
    es: 'Español'
  };
  return names[code] || code;
}

/**
 * Format currency based on language
 */
export function formatCurrency(amount, lang = 'en') {
  const num = Number(amount) || 0;
  return '$' + num.toLocaleString(lang === 'vi' ? 'vi-VN' : lang === 'es' ? 'es-US' : 'en-US');
}

/**
 * Format date based on language
 */
export function formatDate(date, lang = 'en') {
  const d = new Date(date);
  const locales = { en: 'en-US', vi: 'vi-VN', es: 'es-US' };
  return d.toLocaleDateString(locales[lang] || 'en-US');
}

export default {
  translations,
  SUPPORTED_LANGUAGES,
  t,
  getText,
  getLanguageName,
  formatCurrency,
  formatDate
};
// ============================================================
// REVIEW MODAL - File Review Interface
// ============================================================
// Location: frontend/src/components/cpa/ReviewModal.jsx
// ============================================================

import React, { useState } from 'react';

export default function ReviewModal({ file, onClose, onSubmit }) {
  const [status, setStatus] = useState('approved');
  const [comments, setComments] = useState('');
  const [corrections, setCorrections] = useState({});
  const [showCorrections, setShowCorrections] = useState(false);
  const [loading, setLoading] = useState(false);

  const data = file.extractedData || {};

  // Editable fields for W-2
  const editableFields = [
    { key: 'wages_tips_other_comp', label: 'Wages (Box 1)', type: 'number' },
    { key: 'federal_income_tax_withheld', label: 'Federal Withheld (Box 2)', type: 'number' },
    { key: 'social_security_wages', label: 'SS Wages (Box 3)', type: 'number' },
    { key: 'social_security_tax_withheld', label: 'SS Tax (Box 4)', type: 'number' },
    { key: 'medicare_wages_tips', label: 'Medicare Wages (Box 5)', type: 'number' },
    { key: 'medicare_tax_withheld', label: 'Medicare Tax (Box 6)', type: 'number' },
    { key: 'state_income_tax', label: 'State Tax Withheld (Box 17)', type: 'number' },
    { key: 'state_wages', label: 'State Wages (Box 16)', type: 'number' },
  ];

  // Handle field correction
  function handleCorrection(key, value) {
    setCorrections({
      ...corrections,
      [key]: value
    });
  }

  // Submit review
  async function handleSubmit() {
    setLoading(true);
    
    const reviewData = {
      status,
      comments,
      corrections: showCorrections && Object.keys(corrections).length > 0 
        ? corrections 
        : undefined
    };
    
    await onSubmit(file._id, reviewData);
    setLoading(false);
  }

  // Format currency for display
  function formatValue(value) {
    if (value === undefined || value === null) return 'N/A';
    if (typeof value === 'number') return '$' + value.toLocaleString();
    return value;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-4 flex justify-between items-center">
          <div>
            <h2 className="text-xl font-bold">📋 Review Document</h2>
            <p className="text-blue-100 text-sm">
              {file.formType || 'W-2'} • {file.userName || 'Unknown User'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-white hover:text-gray-200 text-2xl"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="grid grid-cols-2 gap-6">
            {/* Left: Document Preview / Extracted Data */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">📄 Extracted Data</h3>
              
              {/* Employee Info */}
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Employee Information</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Name:</span>
                    <span className="font-medium">{data.employee_name || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">SSN:</span>
                    <span className="font-medium font-mono">
                      {data.employee_ssn ? `***-**-${String(data.employee_ssn).slice(-4)}` : 'N/A'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Address:</span>
                    <span className="font-medium text-right text-sm">
                      {data.employee_address || 'N/A'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Employer Info */}
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <h4 className="text-sm font-medium text-gray-500 mb-2">Employer Information</h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Name:</span>
                    <span className="font-medium">{data.employer_name || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">EIN:</span>
                    <span className="font-medium font-mono">{data.employer_ein || 'N/A'}</span>
                  </div>
                </div>
              </div>

              {/* Income Data */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h4 className="text-sm font-medium text-blue-800 mb-2">Income & Withholding</h4>
                <div className="space-y-2">
                  {editableFields.slice(0, 4).map(field => (
                    <div key={field.key} className="flex justify-between">
                      <span className="text-gray-600">{field.label}:</span>
                      <span className="font-medium font-mono">
                        {formatValue(data[field.key])}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* View Original Link */}
              {file.filePath && (
                <a
                  href={`/uploads/${file.filePath}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-block text-blue-600 hover:underline"
                >
                  📎 View Original Document
                </a>
              )}
            </div>

            {/* Right: Review Form */}
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">✍️ Your Review</h3>

              {/* Status Selection */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Decision
                </label>
                <div className="flex gap-4">
                  <label className={`flex-1 p-4 rounded-lg border-2 cursor-pointer text-center transition ${
                    status === 'approved' 
                      ? 'border-green-500 bg-green-50' 
                      : 'border-gray-200 hover:border-green-300'
                  }`}>
                    <input
                      type="radio"
                      name="status"
                      value="approved"
                      checked={status === 'approved'}
                      onChange={() => setStatus('approved')}
                      className="sr-only"
                    />
                    <span className="text-2xl block mb-1">✅</span>
                    <span className={`font-medium ${status === 'approved' ? 'text-green-700' : 'text-gray-700'}`}>
                      Approve
                    </span>
                  </label>
                  
                  <label className={`flex-1 p-4 rounded-lg border-2 cursor-pointer text-center transition ${
                    status === 'rejected' 
                      ? 'border-red-500 bg-red-50' 
                      : 'border-gray-200 hover:border-red-300'
                  }`}>
                    <input
                      type="radio"
                      name="status"
                      value="rejected"
                      checked={status === 'rejected'}
                      onChange={() => setStatus('rejected')}
                      className="sr-only"
                    />
                    <span className="text-2xl block mb-1">❌</span>
                    <span className={`font-medium ${status === 'rejected' ? 'text-red-700' : 'text-gray-700'}`}>
                      Reject
                    </span>
                  </label>
                </div>
              </div>

              {/* Comments */}
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Comments {status === 'rejected' && <span className="text-red-500">*</span>}
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  className="w-full border rounded-lg p-3 h-24 resize-none"
                  placeholder={status === 'rejected' 
                    ? 'Please explain why this document was rejected...'
                    : 'Optional comments...'}
                  required={status === 'rejected'}
                />
              </div>

              {/* Corrections Toggle */}
              <div className="mb-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showCorrections}
                    onChange={(e) => setShowCorrections(e.target.checked)}
                    className="rounded border-gray-300"
                  />
                  <span className="text-sm font-medium text-gray-700">
                    Make corrections to extracted data
                  </span>
                </label>
              </div>

              {/* Corrections Form */}
              {showCorrections && (
                <div className="bg-yellow-50 rounded-lg p-4 mb-4">
                  <h4 className="text-sm font-medium text-yellow-800 mb-3">
                    ⚠️ Correct Values
                  </h4>
                  <div className="space-y-3">
                    {editableFields.map(field => (
                      <div key={field.key} className="flex items-center gap-2">
                        <label className="text-sm text-gray-600 w-40">
                          {field.label}:
                        </label>
                        <input
                          type="number"
                          defaultValue={data[field.key] || ''}
                          onChange={(e) => handleCorrection(field.key, parseFloat(e.target.value))}
                          className="flex-1 border rounded px-2 py-1 text-sm"
                          placeholder="Enter corrected value"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* User Session Data */}
              {file.userData && (
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <h4 className="text-sm font-medium text-gray-500 mb-2">User Session Data</h4>
                  <div className="text-sm space-y-1">
                    <p><span className="text-gray-500">Filing Status:</span> {file.userData.filingStatus || 'Not set'}</p>
                    <p><span className="text-gray-500">Total Wages:</span> ${Number(file.userData.totalWages || 0).toLocaleString()}</p>
                    <p><span className="text-gray-500">Total Withheld:</span> ${Number(file.userData.totalWithheld || 0).toLocaleString()}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-gray-50 px-6 py-4 flex justify-end gap-3 border-t">
          <button
            onClick={onClose}
            className="px-6 py-2 border rounded-lg hover:bg-gray-100"
            disabled={loading}
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={loading || (status === 'rejected' && !comments)}
            className={`px-6 py-2 rounded-lg text-white font-medium ${
              status === 'approved'
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-red-600 hover:bg-red-700'
            } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {loading ? 'Submitting...' : `${status === 'approved' ? '✅ Approve' : '❌ Reject'}`}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// PENDING REVIEWS TABLE - List of files to review
// ============================================================
// Location: frontend/src/components/cpa/PendingReviewsTable.jsx
// ============================================================

import React, { useState } from 'react';

export default function PendingReviewsTable({ 
  files, 
  loading, 
  onSelectFile, 
  onBulkApprove,
  showBulkActions = true 
}) {
  const [selectedIds, setSelectedIds] = useState([]);
  const [selectAll, setSelectAll] = useState(false);

  // Handle select all toggle
  function handleSelectAll() {
    if (selectAll) {
      setSelectedIds([]);
    } else {
      setSelectedIds(files.map(f => f._id));
    }
    setSelectAll(!selectAll);
  }

  // Handle individual selection
  function handleSelect(id) {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
      setSelectAll(false);
    } else {
      const newSelected = [...selectedIds, id];
      setSelectedIds(newSelected);
      if (newSelected.length === files.length) {
        setSelectAll(true);
      }
    }
  }

  // Handle bulk approve
  function handleBulkApprove() {
    if (selectedIds.length > 0 && onBulkApprove) {
      onBulkApprove(selectedIds);
      setSelectedIds([]);
      setSelectAll(false);
    }
  }

  // Format date
  function formatDate(dateString) {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  // Format currency
  function formatCurrency(amount) {
    if (!amount && amount !== 0) return 'N/A';
    return '$' + Number(amount).toLocaleString();
  }

  // Get status badge
  function getStatusBadge(status) {
    const badges = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return badges[status] || 'bg-gray-100 text-gray-800';
  }

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow">
        <div className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-gray-500">Loading files...</p>
        </div>
      </div>
    );
  }

  if (!files || files.length === 0) {
    return (
      <div className="bg-white rounded-lg shadow">
        <div className="p-8 text-center">
          <div className="text-4xl mb-2">📭</div>
          <p className="text-gray-500">No files found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      {/* Bulk Actions Bar */}
      {showBulkActions && selectedIds.length > 0 && (
        <div className="bg-blue-50 px-4 py-3 flex justify-between items-center border-b">
          <span className="text-blue-700">
            {selectedIds.length} file(s) selected
          </span>
          <div className="flex gap-2">
            <button
              onClick={handleBulkApprove}
              className="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700"
            >
              ✅ Bulk Approve
            </button>
            <button
              onClick={() => { setSelectedIds([]); setSelectAll(false); }}
              className="bg-gray-300 text-gray-700 px-4 py-1 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              {showBulkActions && (
                <th className="px-4 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectAll}
                    onChange={handleSelectAll}
                    className="rounded border-gray-300"
                  />
                </th>
              )}
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">User</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Form</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Wages</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Withheld</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Status</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Uploaded</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {files.map((file) => (
              <tr 
                key={file._id} 
                className="hover:bg-gray-50 cursor-pointer"
                onClick={() => onSelectFile(file._id)}
              >
                {showBulkActions && (
                  <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      checked={selectedIds.includes(file._id)}
                      onChange={() => handleSelect(file._id)}
                      className="rounded border-gray-300"
                    />
                  </td>
                )}
                <td className="px-4 py-3">
                  <div>
                    <p className="font-medium text-gray-900">
                      {file.userName || file.extractedData?.employee_name || 'Unknown'}
                    </p>
                    <p className="text-xs text-gray-500">{file.userId}</p>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center px-2 py-1 rounded bg-blue-100 text-blue-800 text-sm">
                    📄 {file.formType || 'W-2'}
                  </span>
                </td>
                <td className="px-4 py-3 font-mono">
                  {formatCurrency(file.extractedData?.wages_tips_other_comp)}
                </td>
                <td className="px-4 py-3 font-mono">
                  {formatCurrency(file.extractedData?.federal_income_tax_withheld)}
                </td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${getStatusBadge(file.status)}`}>
                    {file.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {formatDate(file.uploadedAt)}
                </td>
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <button
                    onClick={() => onSelectFile(file._id)}
                    className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                  >
                    Review →
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

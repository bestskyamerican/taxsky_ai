// ============================================================
// CPA ADMIN CONTROLLER - Manage CPA Users
// ============================================================
// Location: backend/controllers/cpaAdminController.js
// ============================================================

import mongoose from 'mongoose';
import CPA from '../models/CPA.js';

const UploadedFile = mongoose.models.UploadedFile;
const TaxSession = mongoose.models.TaxSession;

// ============================================================
// GET ALL CPAs
// ============================================================
export async function getAllCPAs(req, res) {
  try {
    const { status, role, search, page = 1, limit = 20 } = req.query;
    
    const query = {};
    
    if (status && status !== 'all') {
      query.status = status;
    }
    
    if (role && role !== 'all') {
      query.role = role;
    }
    
    if (search) {
      query.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { licenseNumber: { $regex: search, $options: 'i' } }
      ];
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const [cpas, total] = await Promise.all([
      CPA.find(query)
        .select('-password -passwordResetToken -passwordResetExpires -loginHistory')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      CPA.countDocuments(query)
    ]);
    
    res.json({
      success: true,
      count: cpas.length,
      total,
      page: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      cpas
    });
  } catch (error) {
    console.error('❌ getAllCPAs error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// GET SINGLE CPA
// ============================================================
export async function getCPAById(req, res) {
  try {
    const { cpaId } = req.params;
    
    const cpa = await CPA.findById(cpaId)
      .select('-password -passwordResetToken -passwordResetExpires');
    
    if (!cpa) {
      return res.status(404).json({
        success: false,
        error: 'CPA not found'
      });
    }
    
    // Get review history (last 50 reviews)
    const reviewHistory = await UploadedFile?.find({
      cpaReviewedBy: `${cpa.firstName} ${cpa.lastName}`
    })
      .sort({ cpaReviewedAt: -1 })
      .limit(50)
      .select('formType status cpaReviewedAt userId');
    
    res.json({
      success: true,
      cpa,
      reviewHistory: reviewHistory || []
    });
  } catch (error) {
    console.error('❌ getCPAById error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// APPROVE CPA (Pending → Active)
// ============================================================
export async function approveCPA(req, res) {
  try {
    const { cpaId } = req.params;
    
    const cpa = await CPA.findById(cpaId);
    
    if (!cpa) {
      return res.status(404).json({
        success: false,
        error: 'CPA not found'
      });
    }
    
    if (cpa.status !== 'pending') {
      return res.status(400).json({
        success: false,
        error: `CPA is already ${cpa.status}`
      });
    }
    
    cpa.status = 'active';
    cpa.approvedBy = req.cpa._id;
    cpa.approvedAt = new Date();
    await cpa.save({ validateBeforeSave: false });
    
    console.log(`✅ CPA approved: ${cpa.email} by ${req.cpa.email}`);
    
    // TODO: Send approval email to CPA
    
    res.json({
      success: true,
      message: `CPA ${cpa.firstName} ${cpa.lastName} has been approved`,
      cpa: cpa.toJSON()
    });
  } catch (error) {
    console.error('❌ approveCPA error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// UPDATE CPA STATUS
// ============================================================
export async function updateCPAStatus(req, res) {
  try {
    const { cpaId } = req.params;
    const { status, reason } = req.body;
    
    if (!['active', 'inactive', 'suspended', 'pending'].includes(status)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid status. Must be: active, inactive, suspended, or pending'
      });
    }
    
    const cpa = await CPA.findById(cpaId);
    
    if (!cpa) {
      return res.status(404).json({
        success: false,
        error: 'CPA not found'
      });
    }
    
    // Prevent self-suspension
    if (cpaId === req.cpa._id.toString() && status !== 'active') {
      return res.status(400).json({
        success: false,
        error: 'You cannot change your own status to non-active'
      });
    }
    
    const oldStatus = cpa.status;
    cpa.status = status;
    await cpa.save({ validateBeforeSave: false });
    
    console.log(`✅ CPA status changed: ${cpa.email} ${oldStatus} → ${status} by ${req.cpa.email}`);
    
    res.json({
      success: true,
      message: `CPA status updated to ${status}`,
      cpa: cpa.toJSON()
    });
  } catch (error) {
    console.error('❌ updateCPAStatus error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// UPDATE CPA PERMISSIONS
// ============================================================
export async function updateCPAPermissions(req, res) {
  try {
    const { cpaId } = req.params;
    const { permissions, role } = req.body;
    
    const cpa = await CPA.findById(cpaId);
    
    if (!cpa) {
      return res.status(404).json({
        success: false,
        error: 'CPA not found'
      });
    }
    
    // Prevent changing own permissions
    if (cpaId === req.cpa._id.toString()) {
      return res.status(400).json({
        success: false,
        error: 'You cannot change your own permissions'
      });
    }
    
    const updates = {};
    
    if (permissions) {
      updates.permissions = {
        ...cpa.permissions,
        ...permissions
      };
    }
    
    if (role && ['cpa', 'senior_cpa', 'admin'].includes(role)) {
      updates.role = role;
    }
    
    const updatedCPA = await CPA.findByIdAndUpdate(
      cpaId,
      { $set: updates },
      { new: true }
    );
    
    console.log(`✅ CPA permissions updated: ${cpa.email} by ${req.cpa.email}`);
    
    res.json({
      success: true,
      message: 'Permissions updated successfully',
      cpa: updatedCPA.toJSON()
    });
  } catch (error) {
    console.error('❌ updateCPAPermissions error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// DELETE CPA
// ============================================================
export async function deleteCPA(req, res) {
  try {
    const { cpaId } = req.params;
    
    // Prevent self-deletion
    if (cpaId === req.cpa._id.toString()) {
      return res.status(400).json({
        success: false,
        error: 'You cannot delete your own account'
      });
    }
    
    const cpa = await CPA.findById(cpaId);
    
    if (!cpa) {
      return res.status(404).json({
        success: false,
        error: 'CPA not found'
      });
    }
    
    // Soft delete - just mark as inactive
    cpa.status = 'inactive';
    cpa.email = `deleted_${Date.now()}_${cpa.email}`; // Free up email
    await cpa.save({ validateBeforeSave: false });
    
    console.log(`🗑️ CPA deleted: ${cpa.email} by ${req.cpa.email}`);
    
    res.json({
      success: true,
      message: 'CPA account has been deactivated'
    });
  } catch (error) {
    console.error('❌ deleteCPA error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// GET CPA STATS (Performance metrics)
// ============================================================
export async function getCPAStats(req, res) {
  try {
    const { period = '30' } = req.query; // days
    
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));
    
    // Get all active CPAs with their stats
    const cpas = await CPA.find({ status: 'active' })
      .select('firstName lastName email stats role')
      .sort({ 'stats.totalReviewed': -1 });
    
    // Get reviews in period
    const reviews = await UploadedFile?.aggregate([
      {
        $match: {
          cpaReviewedAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: '$cpaReviewedBy',
          total: { $sum: 1 },
          approved: {
            $sum: { $cond: [{ $eq: ['$status', 'approved'] }, 1, 0] }
          },
          rejected: {
            $sum: { $cond: [{ $eq: ['$status', 'rejected'] }, 1, 0] }
          }
        }
      },
      { $sort: { total: -1 } }
    ]) || [];
    
    // Count by status
    const statusCounts = await CPA.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);
    
    res.json({
      success: true,
      period: parseInt(period),
      statusCounts: statusCounts.reduce((acc, s) => {
        acc[s._id] = s.count;
        return acc;
      }, {}),
      leaderboard: reviews.slice(0, 10),
      allCPAs: cpas
    });
  } catch (error) {
    console.error('❌ getCPAStats error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// GET SYSTEM STATS (Overview)
// ============================================================
export async function getSystemStats(req, res) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const thisWeek = new Date();
    thisWeek.setDate(thisWeek.getDate() - 7);
    
    const thisMonth = new Date();
    thisMonth.setDate(1);
    thisMonth.setHours(0, 0, 0, 0);
    
    // CPA counts
    const cpaStats = await CPA.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);
    
    // File/review counts
    const fileStats = await UploadedFile?.aggregate([
      {
        $facet: {
          byStatus: [
            { $group: { _id: '$status', count: { $sum: 1 } } }
          ],
          today: [
            { $match: { uploadedAt: { $gte: today } } },
            { $count: 'count' }
          ],
          thisWeek: [
            { $match: { uploadedAt: { $gte: thisWeek } } },
            { $count: 'count' }
          ],
          thisMonth: [
            { $match: { uploadedAt: { $gte: thisMonth } } },
            { $count: 'count' }
          ]
        }
      }
    ]) || [{ byStatus: [], today: [], thisWeek: [], thisMonth: [] }];
    
    // User counts
    const userCount = await TaxSession?.countDocuments() || 0;
    
    res.json({
      success: true,
      stats: {
        cpas: {
          total: cpaStats.reduce((sum, s) => sum + s.count, 0),
          byStatus: cpaStats.reduce((acc, s) => {
            acc[s._id] = s.count;
            return acc;
          }, {})
        },
        files: {
          byStatus: fileStats[0].byStatus.reduce((acc, s) => {
            acc[s._id] = s.count;
            return acc;
          }, {}),
          today: fileStats[0].today[0]?.count || 0,
          thisWeek: fileStats[0].thisWeek[0]?.count || 0,
          thisMonth: fileStats[0].thisMonth[0]?.count || 0
        },
        users: {
          total: userCount
        }
      }
    });
  } catch (error) {
    console.error('❌ getSystemStats error:', error);
    res.status(500).json({ success: false, error: error.message });
  }
}

// ============================================================
// EXPORT
// ============================================================
export default {
  getAllCPAs,
  getCPAById,
  approveCPA,
  updateCPAStatus,
  updateCPAPermissions,
  deleteCPA,
  getCPAStats,
  getSystemStats
};

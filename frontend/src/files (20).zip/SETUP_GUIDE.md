# 🏢 TaxSky CPA Dashboard - Setup Guide

## Overview

This CPA Dashboard system allows CPAs to:
- **Login/Register** with secure authentication
- **Review** user-uploaded tax documents (W-2, 1099, etc.)
- **Approve/Reject** documents with comments
- **Make corrections** to extracted data
- **Bulk approve** multiple documents
- **Admin features** for managing other CPAs

---

## 📁 File Structure

```
backend/
├── models/
│   └── CPA.js                    # CPA database model
├── controllers/
│   ├── cpaController.js          # Your existing controller (keep it)
│   ├── cpaAuthController.js      # NEW: Authentication
│   └── cpaAdminController.js     # NEW: Admin management
├── middleware/
│   └── cpaAuth.js                # NEW: Auth middleware
└── routes/
    └── cpaRoutes.js              # NEW: All CPA routes

frontend/src/
├── pages/
│   ├── CPALogin.jsx              # Login page
│   ├── CPARegister.jsx           # Registration page
│   └── CPADashboard.jsx          # Main dashboard
├── components/cpa/
│   ├── StatsCards.jsx            # Statistics display
│   ├── PendingReviewsTable.jsx   # Files table
│   └── ReviewModal.jsx           # Review popup
├── contexts/
│   └── CPAAuthContext.jsx        # Auth state management
└── services/
    └── cpaAPI.js                 # API calls
```

---

## 🔧 Backend Setup

### 1. Install Dependencies

```bash
cd backend
npm install bcryptjs jsonwebtoken
```

### 2. Add Environment Variables

Add to your `.env` file:

```env
JWT_SECRET=your-super-secret-key-change-this-in-production
JWT_EXPIRES_IN=7d
```

### 3. Register Routes

In your `server.js`:

```javascript
import cpaRoutes from './routes/cpaRoutes.js';

// Add CPA routes
app.use('/api/cpa', cpaRoutes);
```

### 4. Create First Admin CPA

Run this in MongoDB shell or create a script:

```javascript
// Create admin CPA directly in database
db.cpas.insertOne({
  email: "admin@taxsky.com",
  password: "$2a$12$...",  // Use bcrypt to hash password
  firstName: "Admin",
  lastName: "User",
  licenseNumber: "ADMIN001",
  licenseState: "CA",
  role: "admin",
  status: "active",
  permissions: {
    canApprove: true,
    canReject: true,
    canEdit: true,
    canDelete: true,
    canManageCPAs: true,
    canViewAllUsers: true,
    canExportData: true
  },
  createdAt: new Date(),
  updatedAt: new Date()
});
```

Or use this Node.js script:

```javascript
// scripts/createAdmin.js
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

dotenv.config();

async function createAdmin() {
  await mongoose.connect(process.env.MONGODB_URI);
  
  const hashedPassword = await bcrypt.hash('AdminPassword123!', 12);
  
  await mongoose.connection.db.collection('cpas').insertOne({
    email: 'admin@taxsky.com',
    password: hashedPassword,
    firstName: 'Admin',
    lastName: 'User',
    licenseNumber: 'ADMIN001',
    licenseState: 'CA',
    role: 'admin',
    status: 'active',
    permissions: {
      canApprove: true,
      canReject: true,
      canEdit: true,
      canDelete: true,
      canManageCPAs: true,
      canViewAllUsers: true,
      canExportData: true
    },
    stats: { totalReviewed: 0, totalApproved: 0, totalRejected: 0 },
    preferences: { language: 'en', theme: 'light' },
    createdAt: new Date(),
    updatedAt: new Date()
  });
  
  console.log('✅ Admin CPA created!');
  console.log('Email: admin@taxsky.com');
  console.log('Password: AdminPassword123!');
  
  process.exit(0);
}

createAdmin();
```

Run: `node scripts/createAdmin.js`

---

## 🎨 Frontend Setup

### 1. Add Routes

In your `App.jsx` or router file:

```jsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { CPAAuthProvider, CPAProtectedRoute } from './contexts/CPAAuthContext';

// CPA Pages
import CPALogin from './pages/CPALogin';
import CPARegister from './pages/CPARegister';
import CPADashboard from './pages/CPADashboard';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* User routes */}
        <Route path="/" element={<TaxChat />} />
        
        {/* CPA routes */}
        <Route path="/cpa/login" element={<CPALogin />} />
        <Route path="/cpa/register" element={<CPARegister />} />
        <Route
          path="/cpa/dashboard"
          element={
            <CPAAuthProvider>
              <CPAProtectedRoute>
                <CPADashboard />
              </CPAProtectedRoute>
            </CPAAuthProvider>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
```

### 2. Wrap App with Provider

```jsx
// main.jsx or index.jsx
import { CPAAuthProvider } from './contexts/CPAAuthContext';

ReactDOM.createRoot(document.getElementById('root')).render(
  <CPAAuthProvider>
    <App />
  </CPAAuthProvider>
);
```

---

## 🔐 API Endpoints

### Authentication

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/cpa/auth/register` | Register new CPA | No |
| POST | `/api/cpa/auth/login` | Login | No |
| GET | `/api/cpa/auth/verify` | Verify token | Yes |
| GET | `/api/cpa/auth/profile` | Get profile | Yes |
| PUT | `/api/cpa/auth/profile` | Update profile | Yes |
| POST | `/api/cpa/auth/change-password` | Change password | Yes |

### Reviews

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/cpa/stats` | Get statistics | Yes |
| GET | `/api/cpa/pending` | Get pending files | Yes |
| GET | `/api/cpa/files` | Get all files | Yes |
| GET | `/api/cpa/files/:id` | Get file details | Yes |
| POST | `/api/cpa/files/:id/review` | Submit review | Yes |
| POST | `/api/cpa/bulk-approve` | Bulk approve | Yes |

### Admin

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| GET | `/api/cpa/admin/cpas` | List all CPAs | Admin |
| POST | `/api/cpa/admin/cpas/:id/approve` | Approve CPA | Admin |
| PUT | `/api/cpa/admin/cpas/:id/status` | Update status | Admin |
| PUT | `/api/cpa/admin/cpas/:id/permissions` | Update permissions | Admin |

---

## 🔄 Workflow

```
┌─────────────────────────────────────────────────────────────┐
│                    CPA WORKFLOW                              │
└─────────────────────────────────────────────────────────────┘

1. CPA REGISTRATION
   ┌─────────┐     ┌─────────┐     ┌─────────┐
   │ Register │ ──► │ Pending │ ──► │ Admin   │
   │ Form     │     │ Status  │     │ Approves│
   └─────────┘     └─────────┘     └─────────┘
                                        │
                                        ▼
                                   ┌─────────┐
                                   │ Active  │
                                   │ Account │
                                   └─────────┘

2. DOCUMENT REVIEW
   ┌─────────┐     ┌─────────┐     ┌─────────┐
   │ User    │ ──► │ Pending │ ──► │ CPA     │
   │ Uploads │     │ Queue   │     │ Reviews │
   └─────────┘     └─────────┘     └─────────┘
                                        │
                        ┌───────────────┼───────────────┐
                        ▼               ▼               ▼
                   ┌─────────┐    ┌─────────┐    ┌─────────┐
                   │ Approve │    │ Reject  │    │ Correct │
                   └─────────┘    └─────────┘    │ & Approve│
                                                 └─────────┘
```

---

## 🎯 Quick Start

1. **Copy all files** to your project
2. **Install dependencies**: `npm install bcryptjs jsonwebtoken`
3. **Add routes** to server.js
4. **Create admin CPA** using the script
5. **Start server**: `npm start`
6. **Login** at `http://localhost:5173/cpa/login`

---

## 🔒 Security Notes

1. **Change JWT_SECRET** in production!
2. **Use HTTPS** in production
3. **Password requirements**: minimum 8 characters
4. **Account lockout**: 5 failed attempts = 30 min lock
5. **Role-based access**: CPA < Senior CPA < Admin

---

## Need Help?

- Check console logs for errors
- Verify MongoDB connection
- Ensure all files are in correct folders
- Test API endpoints with Postman first

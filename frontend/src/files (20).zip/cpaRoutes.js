// ============================================================
// CPA ROUTES - All CPA Dashboard Endpoints
// ============================================================
// Location: backend/routes/cpaRoutes.js
// ============================================================

import express from 'express';
import { protect, restrictTo, requirePermission } from '../middleware/cpaAuth.js';

// Auth Controller
import {
  register,
  login,
  getProfile,
  updateProfile,
  changePassword,
  forgotPassword,
  resetPassword,
  verifyToken,
  logout
} from '../controllers/cpaAuthController.js';

// CPA Controller (existing)
import {
  getPendingReviews,
  getAllFiles,
  getReviewStats,
  submitReview,
  getFileDetails,
  getUserFilings,
  bulkApprove
} from '../controllers/cpaController.js';

// Admin Controller
import {
  getAllCPAs,
  getCPAById,
  approveCPA,
  updateCPAStatus,
  updateCPAPermissions,
  deleteCPA,
  getCPAStats,
  getSystemStats
} from '../controllers/cpaAdminController.js';

const router = express.Router();

// ============================================================
// PUBLIC ROUTES (No auth required)
// ============================================================

// Auth
router.post('/auth/register', register);
router.post('/auth/login', login);
router.post('/auth/forgot-password', forgotPassword);
router.post('/auth/reset-password', resetPassword);

// ============================================================
// PROTECTED ROUTES (Auth required)
// ============================================================

// Apply protect middleware to all routes below
router.use(protect);

// Auth (protected)
router.get('/auth/verify', verifyToken);
router.post('/auth/logout', logout);
router.get('/auth/profile', getProfile);
router.put('/auth/profile', updateProfile);
router.post('/auth/change-password', changePassword);

// ============================================================
// REVIEW ROUTES (CPA work)
// ============================================================

// Dashboard stats
router.get('/stats', getReviewStats);

// Pending reviews
router.get('/pending', getPendingReviews);

// All files (with filters)
router.get('/files', getAllFiles);

// Single file details
router.get('/files/:fileId', getFileDetails);

// Submit review (approve/reject)
router.post('/files/:fileId/review', requirePermission('canApprove'), submitReview);

// Bulk approve
router.post('/bulk-approve', requirePermission('canApprove'), bulkApprove);

// User filings (all documents for a user)
router.get('/users/:userId/filings', getUserFilings);

// ============================================================
// ADMIN ROUTES (Admin/Senior CPA only)
// ============================================================

// CPA Management
router.get('/admin/cpas', restrictTo('admin', 'senior_cpa'), getAllCPAs);
router.get('/admin/cpas/:cpaId', restrictTo('admin', 'senior_cpa'), getCPAById);
router.post('/admin/cpas/:cpaId/approve', restrictTo('admin'), approveCPA);
router.put('/admin/cpas/:cpaId/status', restrictTo('admin'), updateCPAStatus);
router.put('/admin/cpas/:cpaId/permissions', restrictTo('admin'), updateCPAPermissions);
router.delete('/admin/cpas/:cpaId', restrictTo('admin'), deleteCPA);

// Admin Stats
router.get('/admin/cpa-stats', restrictTo('admin', 'senior_cpa'), getCPAStats);
router.get('/admin/system-stats', restrictTo('admin'), getSystemStats);

// ============================================================
// EXPORT
// ============================================================
export default router;
